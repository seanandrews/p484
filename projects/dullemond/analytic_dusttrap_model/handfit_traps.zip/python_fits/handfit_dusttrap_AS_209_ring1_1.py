#
# Here we do a hand-fitting of the parameters
#
# WARNING: The parameters are here NOT exp / log...
#

import numpy as np
import matplotlib.pyplot as plt
from natconst import *
from convolve_gauss_1d import *
from bplanck import *
from analytic_trap_model import *
from interactive_plot import *

def disktemp(r):
    global fixedparams
    lstar   = fixedparams['lstar']    # Stellar luminosity
    flang   = fixedparams['flang']    # Flaring angle of disk surface
    firr    = 0.5*flang*lstar/(4*pi*r**2)    # Irradiating flux
    temp    = (firr/ss)**0.25                # Midplane temperature
    return temp

def modelfunction(robsau,params,checkvalid=False):
    global fixedparams
    robs    = robsau*au
    #
    # Parameters to be fitted
    #
    agrmin  = params[0]       # Minimum grain size
    agrmax  = params[1]       # Maximum grain size
    mdust   = params[2]       # Total dust mass
    w       = params[3]       # Width of ring in gas
    alphat  = params[4]       # Turbulence alpha
    r0      = params[5]*au    # Radius of ring
    
    #print("params_start = np.array([{0:11.4e},{1:11.4e},{2:11.4e},{3:11.4e},{4:11.4e},{5:11.4e}])".format(params[0],params[1],params[2],params[3],params[4],params[5]))
    
    #
    # Fixed parameters
    #
    mstar   = fixedparams['mstar']    # Stellar mass
    na      = fixedparams['na']       # Nr of grain size samplings
    qdust   = fixedparams['qdust']    # Powerlaw for the grain size distribution
    sigmag0 = fixedparams['sigmag0']  # Some estimate of Sigma_gas(r_0)
    xigrain = fixedparams['xigrain']  # Material density of the grain in g/cm^3
    Sc      = fixedparams['Sc']       # Schmidt number
    lam     = fixedparams['lam']      # Band 6 of ALMA lambda = 1.3 mm
    dpc     = fixedparams['dpc']      # Distance
    beamas  = fixedparams['beamas']   # Average beam in band 6
    dr      = fixedparams['dr']       # width of the grid
    nr      = fixedparams['nr']       # Nr of radial points 
    #
    # Create a radial grid, linearly spaced
    #
    rin     = r0-dr
    rout    = r0+dr
    r       = rin + (rout-rin)*np.linspace(0.,1.,nr)
    #
    # Now either 'just' check validity or return the full model
    #
    if checkvalid:
        #
        # Only check validity
        #
        agrain  = np.array([agrmin])           # Must be the smallest grain
        mdusti  = np.array([mdust])
        tgas0   = disktemp(r0)
        return analytic_trap_model(r,agrain,mdusti,mstar,r0,sigmag0,tgas0,w,alphat,xigrain=xigrain,Sc=1.0,checkvalid=True)
    else:
        #
        # Create the size distribution
        #
        agrain  = agrmin * (agrmax/agrmin)**np.linspace(0.,1.,na)  # Log grid
        mgrain  = (4*pi/3.)*xigrain*agrain**3  # Grain mass
        mdusti  = agrain**qdust       # Grain size distribution 
        mdusti *= mdust/mdusti.sum()  # Normalize with simple sum is ok, because log grid in a
        #
        # Make analytic model
        #
        tgas0 = disktemp(r0)
        tgas  = disktemp(r)
        sigdust, wdust, ddust, tstop, St = \
              analytic_trap_model(r,agrain,mdusti,mstar,r0,sigmag0,tgas0,w,alphat,xigrain=xigrain,Sc=1.0)
        intbright, tbright, tau, bpl = \
              analytic_tbright_model(r,agrain,lam,sigdust,tgas,xigrain=xigrain)
        model = np.interp(robs,r,tbright[0,:])
        intconv = \
              convolve_intbright_lingrid(r[1]-r[0],intbright,beamas,dpc)
        tbrconv = tbright_linear(cc/lam[0],intconv[0,:])
        modelconv = np.interp(robs,r,tbrconv)
        #
        # Make the mock functions for the beam, H_p and w, all Gaussians
        #
        dpc       = fixedparams['dpc']
        beamas    = fixedparams['beamas']
        beamau    = beamas*dpc
        beamsig   = beamau/2.35482
        mstar     = fixedparams['mstar']
        cs        = np.sqrt(kk*disktemp(r0)/(2.3*mp))
        omk       = np.sqrt(GG*mstar/r0**3)
        hp        = cs/omk
        if 'ampldummy' in fixedparams:
            ampl  = fixedparams['ampldummy']
        else:
            ampl  = model.max()
        gaussbeam = ampl*np.exp(-0.5*((robs-r0)/au)**2/beamsig**2)
        gausshp   = ampl*np.exp(-0.5*(robs-r0)**2/hp**2)
        gaussbump = ampl*np.exp(-0.5*(robs-r0)**2/w**2)
        #
        # Return
        #
        return np.vstack((model,modelconv,gaussbeam,gausshp,gaussbump))

#---------------------------------------------------------------------
#
# Name of source
#
name = 'AS_209'
ring = 'ring1'
#
# Fixed parameters
#
global fixedparams
fixedparams = {}
fixedparams['mstar']     = 10**(-0.04)*MS     # Stellar mass of AS 209 (from github wiki 2018.05.13)
fixedparams['lstar']     = 10**(-0.20)*LS     # Stellar luminosity of AS 209 (from github wiki 2018.05.13)
fixedparams['flang']     = 0.02               # Assumed flaring angle of disk surface
fixedparams['r00au']     = 74.                # Radius of ring 1
fixedparams['na']        = 10                 # Nr of grain size samplings
fixedparams['qdust']     = 0.5                # Powerlaw for the grain size distribution
fixedparams['sigmag0']   = 0.01*MS/(pi*(fixedparams['r00au']*au)**2) # Some estimate of Sigma_gas(r_0)
fixedparams['xigrain']   = 2.0                # Material density of the grain in g/cm^3
fixedparams['Sc']        = 1.0                # Schmidt number
fixedparams['lam']       = np.array([0.13])   # Band 6 of ALMA lambda = 1.3 mm
fixedparams['dpc']       = 121                # Distance to AS 209 (2018.05.08 from Wiki)
fixedparams['beamas']    = np.array([35e-3])  # Average beam in band 6: 35 milli-as (42x29 mas) Elias 24 ---> Check for AS 209
fixedparams['dr']        = 20*au              # width of the grid
fixedparams['nr']        = 1000               # Nr of radial points 
#
# Read the data
#
with open(name+'_radial_tbright_linear.txt','r') as f:
    f.readline()
    data = np.loadtxt(f)
    obs_rau,obs_tbr_lin = data.T
obs_r     = obs_rau*au
#
# As error we simply take 0.1 K *** HACK WARNING ***
#
obs_tbr_err = np.ones_like(obs_tbr_lin) * 0.1
#
# Extract the part that we want to fit
# 
ir        = np.where(np.logical_and(obs_rau>63.,obs_rau<87.))
obs_ext_r = obs_r[ir]
obs_ext_t = obs_tbr_lin[ir]
obs_ext_e = obs_tbr_err[ir]
nr        = len(obs_r)
#
# For the additional curves of the handfitting widget
#
fixedparams['ampldummy'] = obs_ext_t.max()
#
# Initial guess params
#
params_names = np.array(["agrmin = ","agrmax = ","mdust = ","w = ","alphat = ","r0au = "])
iparams_start = np.array([4,32,151,47,18,50])

#
# Plot 
#
params_choices = [10**np.linspace(-5,1,100),10**np.linspace(-5,1,100), \
                  10**np.linspace(27,30,300),np.linspace(5*au,30*au,100), \
                  10**np.linspace(-6,-1,100),fixedparams['r00au']*np.linspace(0.95,1.05,100)]
fig    = plt.figure()
x      = obs_ext_r
data   = obs_ext_t
ax     = plt.axes(xlim=(obs_ext_r.min()/au,obs_ext_r.max()/au),ylim=(0,5.5))
axm0,  = ax.plot(x,data,'--',label='model')
axm1,  = ax.plot(x,data,linewidth=2,label='model (convolved)')
axm2,  = ax.plot(x,data,':',label='beam')
axm3,  = ax.plot(x,data,':',label='hp')
axm4,  = ax.plot(x,data,':',label='bump')
axmodel= [axm0,axm1,axm2,axm3,axm4]
plt.plot(obs_ext_r[::8]/au,obs_ext_t[::8],'o',markerfacecolor='none',label='Observations ALMA band 6')
plt.xlabel(r'$r [\mathrm{au}]$',fontsize=15)
plt.ylabel(r'$T_{\mathrm{br,lin}} [\mathrm{K}]$',fontsize=15)
plt.text(obs_ext_r.min()/au+1,4.8,'AS 209\nRing 1',fontsize=15)
ax.legend(fontsize=12,loc='upper right')
interactive_plot(obs_ext_r/au, modelfunction, params_choices, parnames=params_names, \
                 fig=fig, ax=ax, iparstart=iparams_start, axmodel=axmodel)
plt.show()
