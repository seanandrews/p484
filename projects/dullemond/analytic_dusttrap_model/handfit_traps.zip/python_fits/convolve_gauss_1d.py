import numpy as np
from scipy import convolve

def convolve_gauss_1d(y,dx_grid,dx_gauss_fwhm,edge=True,periodic=False):
    """
    Simple 1-D convolution of a tabulated function y(x), where y is a numpy array,
    dx_grid is the grid spacing in x, and dx_smooth_fwhm is the full-width-half-max
    Gaussian kernel width of the smoothing. If edge==True, then the edge value is
    extrapolated to prevent the smoothed function from dropping to zero near the
    edges. If periodic==True, then this is done by copying from the other side.
    """
    dx      = dx_grid
    nxkh    = int(2*dx_gauss_fwhm/dx)
    ny      = len(y)
    if edge:
        nyy     = ny+2*nxkh
        yy      = np.zeros(nyy)
        yy[nxkh:-nxkh] = y[:]
        if periodic:
            yy[0:nxkh]  = y[-nxkh:]
            yy[-nxkh:] = y[0:nxkh]
        else:
            yy[0:nxkh]  = y[0] # Bugfix 2018.05.07
            yy[-nxkh:] = y[-1] # Bugfix 2018.05.07
    else:
        nyy     = ny
        yy      = y
    nxk     = 1+2*nxkh
    rkern   = nxk*dx
    xk      = np.linspace(-rkern/2,rkern/2,nxk)
    sigma   = dx_gauss_fwhm/2.355    # Convert from FWHM to sigma
    kernel  = np.exp(-0.5*(xk/sigma)**2)
    kernel  = kernel/kernel.sum()
    yynew    = convolve(kernel,yy,mode='same')
    if edge:
        ynew = yynew[nxkh:-nxkh]
    else:
        yneq = yynew
    return ynew

