import numpy as np
from natconst import *
from convolve_gauss_1d import *
from bplanck import *

def tbright_linear(nu,intensity):   # The linear brightness temperature
    const3  = 2*kk/cc**2
    return intensity / ( const3*(nu**2) )

def analytic_trap_model(rgrid,agrid,massdistr,mstar,r0,siggas0,tgas0,w,alphat,xigrain=2.0,Sc=1.0,checkvalid=False):
    """
    The analytic narrow dust trap model. Computes the surface density profile 
    Sigma_dust(r) for a set of grain sizes, given a pressure bump at radius r0
    with standard deviation width w. 

    ARGUMENTS:
      rgrid       The radial grid [cm]
      agrid       The grain radius grid [cm]
      massdistr   The total dust masses on each of the agrid points [g]
      mstar       The stellar mass [g]
      r0          The location of the peak of the pressure [cm]
      siggas0     The gas surface density at r0 [g/cm^2]
      tgas0       The gas temperature at r0 [K]
      w           The standard-deviation width of the pressure bump [cm]
      alphat      The turbulent strength alpha

    OPTIONAL ARGUMENTS:
      xigrain     The material density of the grains [g/cm^3] (default=2.0)
      Sc          The Schmidt number (default=1.0)
      checkvalid  If True, then do not do the modeling, but just check if model 
                  is valid in this parameter range (default=False)

    RETURNS:
      sigdust     Array Sigma_dust[ia,ir] in [g/cm^2]
      wdust       Array of standard deviation width of the dust Gauss w_dust[ia] in [cm]
      ddust       Array of diffusion coefficient D_d[ia] in [cm^2/s]
      tstop       Array of stopping times t_stop[ia] in [s]
      St          Array of Stokes numbers St[ia]
    """
    nr      = len(rgrid)
    na      = len(agrid)
    r       = rgrid
    agrain  = agrid
    sigdust = np.zeros((na,nr))
    wdust   = np.zeros(na)
    St      = np.zeros(na)
    tstop   = np.zeros(na)
    ddust   = np.zeros(na)
    omk     = np.sqrt(GG*mstar/r0**3)         # Omega_K
    cs      = np.sqrt(kk*tgas0/(2.3*mp))      # Isothermal sound speed
    vth     = np.sqrt(8*kk*tgas0/(pi*2.3*mp)) # Average molecular velocity
    hp      = cs/omk                          # Gas pressure scale height
    rhog0   = siggas0/(np.sqrt(2*pi)*hp)      # Midplane gas density
    nut     = alphat*cs**2/omk                # Turbulent viscosity
    dgas    = nut/Sc                          # Gas turbulent diffusion coefficient
    mgrain  = (4*pi/3.)*xigrain*agrain**3     # Grain mass
    assert w>=hp, "ERROR: Gas bump width < pressure scale height."
    if checkvalid:
        ia        = 0  # The smallest grain must always be the first one
        tstop     = 3*mgrain[ia]/(4*pi*agrain[ia]**2*rhog0*vth)  # t_stop in Epstein regime
        St        = omk*tstop
        wdust     = w*np.sqrt(alphat/(Sc*St))
        if wdust <= w:
            return True
        else:
            return False
    else:
        for ia in range(na):
            tstop[ia]     = 3*mgrain[ia]/(4*pi*agrain[ia]**2*rhog0*vth)  # t_stop in Epstein regime
            St[ia]        = omk*tstop[ia]
            ddust[ia]     = dgas/(1.+St[ia]**2)
            wdust[ia]     = w*np.sqrt(alphat/(Sc*St[ia]))
            if wdust[ia] > w:
                print("Warning: approximation breaks down for grain {0:d}".format(ia))
            if wdust[ia]>w: wdust[ia]=w   # Rather brute fix
            sigdust[ia,:] = (massdistr[ia]/((2*pi)**1.5*r0*wdust[ia])) * \
                            np.exp(-0.5*(r-r0)**2/wdust[ia]**2)
        return sigdust, wdust, ddust, tstop, St

def analytic_tbright_model(rgrid,agrid,lam,sigdust,tdisk,xigrain=2.0):
    """
    Compute the linear brightness temperature as a function of radius and
    wavelength, given a grain size distribution. We use a super-simple
    opacity model (the model of Ivezic et al.). 

    ARGUMENTS:
      rgrid       The radial grid [cm]
      agrid       The grain radius grid [cm]
      lam         The wavelength of observation [cm]
      sigdust     The dust surface density Sigma_d[ia,ir] in [g/cm^2]
      tdisk       The disk temperature as a function of radius [K]
      
    OPTIONAL ARGUMENTS:
      xigrain     The material density of the grains [g/cm^3] (default=2.0)

    RETURNS:
      intbright   The intensity as a function of frequency and r [erg/s/cm^2/Hz/ster]
      tbright     The linear brightness temperature as a function of frequency and r [K]
      tau         The optical depth as a function of frequency and r
      bpl         The Planck function as a function of frequency and r [erg/s/cm^2/Hz/ster]
    """
    #
    # Create the simple opacity model of Ivezic
    #
    agrain = agrid
    mgrain = (4*pi/3.)*xigrain*agrain**3     # Grain mass
    na     = len(agrain)
    nlam   = len(lam)
    kappa  = np.zeros((nlam,na))
    for ia in range(na):
        kappa[:,ia] = pi*agrain[ia]**2/mgrain[ia]
        for inu in range(nlam):
            if 2*pi*agrain[ia] < lam[inu]:
                kappa[inu,ia] *= 2*pi*agrain[ia]/lam[inu]
    #
    # Compute the total optical depth
    #
    nr  = len(rgrid)
    tau = np.zeros((nlam,nr))
    for inu in range(nlam):
        for ia in range(na):
            tau[inu,:] += sigdust[ia,:]*kappa[inu,ia]
    #
    # Compute 1-exp(-tau)
    #
    xp = 1-np.exp(-tau)
    #
    # Now compute, for the simple T(r) model, the Planck function B_nu(T(r))
    #
    bpl   = np.zeros((nlam,nr))
    for ir in range(nr):
        for inu in range(nlam):
            bpl[inu,ir] = bplanck(cc/lam[inu],tdisk[ir])
    #
    # Next compute the model intensity
    #
    intbright    = xp * bpl
    tbright      = np.zeros((nlam,nr))
    for inu in range(nlam):
        tbright[inu,:] = tbright_linear(cc/lam[inu],intbright[inu,:])
    #
    # Finish
    #
    return intbright, tbright, tau, bpl

def convolve_intbright(rgrid,intbright,beamas,dpc,nx=1000):
    """
    Convolve an intensity profile I_nu(r) with a gaussian beam in 1-D.
    Note: actually the convolution has to be done in 2-D, but as long 
    as r is much larger than the beam this should be ok.

    ARGUMENTS:
      rgrid       The radial grid [cm]
      intbright   The I_nu(r) = intbright[inu,ir]
      beamas      The beam FWHM in [arcsec]
      dpc         Distance to the source in [parsec]

    OPTIONAL ARGUMENTS:
      nx          Nr of radial grid points for the linear grid

    RETURNS:
      x           Linear grid in r [cm]
      intconv     Convolved intensity[inu,ir]
    """
    nlam    = len(beamas)
    assert intbright.shape[0]==nlam, "Beam must have same nr of wavelength points as intbright"
    beam    = beamas*dpc*au
    r       = rgrid
    x       = np.linspace(r.min(),r.max(),nx)
    intconv = np.zeros((nlam,nx))
    for inu in range(nlam):
        y              = np.interp(x,r,intbright[inu,:])
        intconv[inu,:] = convolve_gauss_1d(y,x[1]-x[0],beam[inu],periodic=False)
    return x,intconv

def convolve_intbright_lingrid(dr,intbright,beamas,dpc):
    """
    Convolve an intensity profile I_nu(r) with a gaussian beam in 1-D.
    Note: actually the convolution has to be done in 2-D, but as long 
    as r is much larger than the beam this should be ok.

    ARGUMENTS:
      dr          The radial grid spacing (linear grid assumed!) [cm]
      intbright   The I_nu(r) = intbright[inu,ir]
      beamas      The beam FWHM in [arcsec]
      dpc         Distance to the source in [parsec]

    RETURNS:
      intconv     Convolved intensity[inu,ir]
    """
    nlam    = len(beamas)
    assert intbright.shape[0]==nlam, "Beam must have same nr of wavelength points as intbright"
    beam    = beamas*dpc*au
    intconv = np.zeros((nlam,intbright.shape[1]))
    for inu in range(nlam):
        intconv[inu,:] = convolve_gauss_1d(intbright[inu,:],dr,beam[inu],periodic=False)
    return intconv

