import numpy as np
from .. import natconst as nc
import matplotlib.pyplot as plt
import subprocess

from disklab.natconst import au


def bplanck(freq, temp):
    """
    This function computes the Planck function

                   2 h nu^3 / c^2
       B_nu(T)  = ------------------    [ erg / cm^2 s ster Hz ]
                  exp(h nu / kT) - 1

    Arguments:
    ----------

    freq : float
        Frequency [Hz]

    temp : float
        temperature [K]

    Output:
    -------

    bpl: float
        Planck function [ erg / (cm^2 s ster Hz)]
    """

    h = nc.hh
    k = nc.kk
    cc = nc.cc

    const1 = h / k
    const2 = 2 * h / cc**2
    const3 = 2 * k / cc**2
    x = const1 * freq / (temp + 1e-99)
    if x > 1.e-3:
        bpl = const2 * (freq**3) / (np.exp(x) - 1e0)
    else:
        bpl = const3 * (freq**2) * temp
    return bpl


def write(fid, *args, **kwargs):
    """
    Helper function to write out automatically formated
    values separated by spaces in one line.

    Arguments:
    ----------
    fid : file handle
        file handle of the file into which to write

    *args : list of arguments
        every argument is written to the file, separated by `sep`
        which is usually a single space

    Keywords:
    ---------
    fmt : format string
        usually empty, and will automatically format elements to string
        can be set to any python format statement (whatever is between
        the {}-brackets).

    sep : str
        separating string. can be new line, then every argument is
        written in new line.

    Examples:
    ---------

    Write a "1" in a single line:
    >>> write(fid,1)

    Write the 1D array `A` to the file, one element per line
    >>> write(fid,*A,sep='\n')
    """
    fmt = kwargs.pop('fmt', '')
    sep = kwargs.pop('sep', ' ')
    fid.write(sep.join([('{' + fmt + '}').format(a) for a in args]) + '\n')


def radmc3d(command):
    """
    convenience function to run RADMC3D with the given commands
    and write out the result in real time

    Arguments:
    ----------
    command : str
        radmc3d command, such as 'image inc 45':
    """
    proc = subprocess.Popen(['radmc3d'] + command.split(),
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for line in iter(proc.stdout.readline, b''):
        print('>>>   ' + line.decode().rstrip())


def plotgrid(r=None, ri=None, theta=None, thetai=None, data=None, xlim=None, ylim=None, zlim=None,
             zax=None, ax=None, ptype='contourf', style='xy', nlevels=None, **kwargs):
    """
    Plot a quantity on the grid. The quantity is assumed to be in logspace, otherwise you need to
    specify zlim and nlevels accordingly

    Keywords:
    ---------

    r : array
        the radial grid centers (1D)

    ri : array
        the radial grid interfaces (1D)

    theta : array
        theta grid centers (1D)

    thetai : array
        theta grid interfaces (1D)

    data : array
         2D data array

    xlim : array (2 elements)
        the axes extend in y

    ylim : array (2 elements)
        the axes extend in y

    zlim : array (2 elements)
        the axes extend in z

    zax : array
        specifies the ticks (and extend) of the z-axis. Usually
        this only needs to be set for linear z data, for logarithmic
        zdata, its usually easier to specify zlim and possibly nlevels.

    ax : [*None* | matplotlib.axes]
        into which axes to plot the figure, if *None*, new figure is created

    ptype : string
        specifies what kind of plot to produce. Options are
        -    contourf
        -    contour
        -    pcolormesh

    style : string
        specifies which way the axes are formatted
        -    'xy': normal 2D spacial plot
        -    'rt': r-theta plot

    nlevels : int
        number of coutour levels (for contour plots)

    **kwargs will be passed to the plotting command. For an example, see below-

    Example:
    --------

    >>> plotgrid(r=ri/AU,theta=thetai,data=log10(rhodust_t),ptype='pcolormesh',**{'edgecolor':'face','alpha':0.5})
    >>> gca().set_axis_bgcolor('k')
    >>> draw()

    """
    #
    # assing values if they are not set
    #
    if zlim is None:
        zlim = np.ceil(data[np.invert(np.isnan(data))].max()) + np.array([-20, 0])
    if nlevels is None:
        nlevels = zlim[-1] - zlim[0] + 1
    if zax is None:
        zax = np.linspace(zlim[0], zlim[-1], nlevels)
    if ax is None:
        f, ax = plt.subplots()
    else:
        f = plt.figure(ax.figure.number)
        f.sca(ax)
    #
    # calculate X and Y coordinates from r and theta
    #
    if style == 'xy':
        X = np.tile(r[:, None], [1, len(theta)]) * \
            np.sin(np.tile(theta, [len(r), 1]))
        Y = np.tile(r[:, None], [1, len(theta)]) * \
            np.cos(np.tile(theta, [len(r), 1]))
        Xi = np.tile(ri[:, None], [1, len(thetai)]) * \
            np.sin(np.tile(thetai, [len(ri), 1]))
        Yi = np.tile(ri[:, None], [1, len(thetai)]) * \
            np.cos(np.tile(thetai, [len(ri), 1]))
        if xlim is None:
            xlim = [0, Xi.max()]
        if ylim is None:
            ylim = [0, Yi.max()]
    elif style == 'rt':
        X = r
        Xi = ri
        Y = np.pi / 2 - theta
        Yi = np.pi / 2 - thetai
        data = data.T
        if xlim is None:
            xlim = [0, Xi.max()]
        if ylim is None:
            ylim = [0, Yi.max()]
    #
    # plotting
    #
    if ptype == 'contourf':
        ax.contourf(X, Y, data, zax, **kwargs)
    elif ptype == 'contour':
        ax.contour(X, Y, data, zax, **kwargs)
    elif ptype == 'pcolormesh':
        ax.pcolormesh(Xi, Yi, data, vmin=zax[0], vmax=zax[-1], clim=zax, **kwargs)
    #
    # plot formatting
    #
    ax.set_xlim(xlim)
    ax.set_ylim(ylim)

    return ax


def plotmesh(ri=None, thetai=None, r=None, theta=None, style='xy', scale=None, ax=None):
    """
    Plot the grid mesh

    Keywords:
    ---------

    ri : float
        radial grid interfaces

    thetai : float
        theta grid interfaces

    r : float
        radial grid center positions

    theta : float
        theta grid center positions

    scale : float
        divide distance units by this factor, default: AU

    style : string
         'xy' = axes are x and y
         'rt' = axes are r and theta
    """
    scale = scale or au
    if ax is None:
        fs = max(plt.rcParams['figure.figsize'])
        f = plt.figure(figsize=[fs, fs])
        ax = f.add_subplot(111)
        if style == 'xy':
            ax.set_xlabel('x')
            ax.set_ylabel('y')
        elif style == 'rt':
            ax.set_xlabel('r')
            ax.set_ylabel('$\pi/2-\\theta$')
    #
    # plot radial grid centers
    #
    if style == 'xy':
        if r is not None and theta is not None:
            r = r / au
            for t in theta:
                ax.plot(r * np.sin(t), r * np.cos(t),
                        c='k', ls='', marker='.')
        if ri is not None and thetai is not None:
            ri = ri / au
            for t in thetai:
                ax.plot(ri * np.sin(t), ri * np.cos(t), c='k', ls='-')
            for rr in ri:
                ax.plot(rr * np.sin(thetai), rr * np.cos(thetai), c='k', ls='-')
    if style == 'rt':
        if r is not None and theta is not None:
            r = r / au
            for t in theta:
                ax.plot(r, np.pi / 2 - t * np.ones(len(r)), c='k', ls='', marker='.')
        if ri is not None and thetai is not None:
            ri = ri / au
            for t in thetai:
                ax.plot(ri, np.pi / 2 - t * np.ones(len(ri)), c='k', ls='-')
            for rr in ri:
                ax.plot(rr * np.ones(len(thetai)), np.pi / 2 - thetai, c='k', ls='-')


def plot_vert_structure(disk2d, kappa_dust=1e2, tcontours=True):
    """
    Plot the density, temperature, and radial optical depth for a 2d model.

    Arguments:
    ----------
    disk2d : instance of disklab.Diskvert2d
        grids and quantities are derived from this object

    Keywords:
    ---------
    kappa_dust : float | array
        absorption opacity assumed when calculating dust densities [cm^2/g]
        needs to be a float or an array with the shape (nr, ntheta, ndust)

    tcontours : bool
        whether or not to plot contour lines of the temperature

    Output:
    -------
    X,Z : arrays
        radius and vertical height grids

    rho, T, tau_r : arrays
        density, temperature, and optical depth arrays on grid X, Z

    f : figure
        the figure handle of the plot
    """
    from scipy.integrate import cumtrapz
    # Get grid arrays from verts

    Z = np.array([vert.z for vert in disk2d.verts])
    X = disk2d.r[:, None] * np.ones_like(Z)

    # Get arrays for $\rho$, $T$, and $\tau$

    rho = np.array([[dust.rho for dust in vert.dust] for vert in disk2d.verts]).swapaxes(1, 2)
    rho_t = rho.sum(-1)
    T = np.array([vert.tgas for vert in disk2d.verts])
    tau_r = cumtrapz((rho * kappa_dust).sum(-1).T, x=disk2d.r, initial=1e-100).T

    # PLOTTING

    f, axs = plt.subplots(3, 1, figsize=(15, 8), sharex=True, sharey=True)

    # density

    vmax = np.ceil(np.log10(rho_t.max()))
    cc = axs[0].pcolormesh(X / au, Z / X, np.log10(rho_t + 1e-100),
                           vmin=vmax - 8, vmax=vmax)  # gist_heat_r
    cb = plt.colorbar(cc, ax=axs[0])
    cb.set_label(r'$\log(\rho)$ [g cm$^{-3}$]')

    # temperature

    vmax = np.ceil(T.max())
    cc = axs[1].pcolormesh(X / au, Z / X, T, vmin=1,
                           vmax=vmax, cmap='coolwarm')  # gist_heat_r
    cb = plt.colorbar(cc, ax=axs[1])
    cb.set_label(r'$T$ [K]')

    c = axs[1].contour(X / au, Z / X, T, 10, colors='w')
    plt.clabel(c, inline=1, fontsize='xx-small')

    # radial optical depth

    cc = axs[2].pcolormesh(
        X / au, Z / X, np.log10(tau_r + 1e-100), vmin=-1, vmax=1, cmap='RdGy')
    cb = plt.colorbar(cc, ax=axs[2])
    cb.set_label(r'$\log(\tau_r)$ ')

    # labels

    for ax in axs:
        ax.set_ylabel('$z/r$')
    ax.set_xlabel('$r$ [au]')
    ax.set_ylim(0, 0.4)
    ax.set_xscale('log')
    f.subplots_adjust(hspace=0.1, wspace=0.05)

    return X, Z, rho, T, tau_r, f


def write_stars_input(d, lam_mic):
    """
    Writes out the stars.inp file based on the stellar properties of the
    disklab model d. For now just using a blackbody star.

    Arguments:
    ----------

    d : model instance from disklab
        takes stellar properties from this model

    lam_mic : array
        wavelength array in micrometers
    """
    with open('stars.inp', 'w') as f:
        write(f, 2)  # format identifier
        write(f, 1, len(lam_mic))  # number of stars, number of wavelengths
        write(f, d.rstar, d.mstar, 0, 0, 0)  # radius, mass, xyz position
        write(f, *lam_mic, sep='\n')         # the wavelength grid

        # if only a negative value is given, then this is used as Teff of a BB spectrum

        write(f, -d.tstar)


def write_grid(ri, thetai, phii):
    """
    Writes the grid to the RADMC3D inputfile amr_grid.inp

    Arguments:
    ----------
    ri : array
        radial interface grid

    thetai : array
        theta grid, measuring angle up from mid-plane.

    phii : array
        phi grid, should be [0,2*np.pi]
    """

    assert thetai[0] == 0, "thetai should start at 0 and increase - will be transformed to radmc3d coordinates"
    assert phii[0] == 0, "phii[0] should be zero"
    assert phii[-1] == 2 * np.pi, "phii[1] should be 2*pi"

    with open('amr_grid.inp', 'w') as f:
        write(f, 1)        # format identifier
        write(f, 0)        # 0 = regular grid
        write(f, 100)      # 100 = spherical
        write(f, 0)        # (always 0)
        write(f, 1, 1, 0)  # include x- and y-coordinate
        write(f, len(ri) - 1, len(thetai) - 1, len(phii) - 1)  # grid size

        # the cell interface radii

        write(f, *ri, sep='\n')

        # the cell interface theta

        write(f, *(np.pi / 2 - thetai[::-1]), sep='\n')

        # the cell interfaces in phi

        write(f, *phii, sep='\n')


def write_dust_density(rho2):
    """
    Write the dust density array rho2 to the radmc3d input file dust_density.inp

    Arguments:
    ----------
    rho2 : np.array
        2D array with (nr,ntheta), where the first theta values correspond to mid-plane values
    """
    with open('dust_density.inp', 'w') as f:
        write(f, 1)                    # Format identifier
        write(f, np.prod(rho2.shape))  # Number of cells
        write(f, 1)                    # Nr of dust species

        # write out the density

        write(f, *(rho2[:, ::-1].ravel(order='F')), sep='\n')
        write(f, '\n')


def write_wavelength_micron(lam_mic):
    """
    writes the wavelength grid (given in micron) to the RADMC3D input file wavelength_micron.inp

    Arguments:
    ----------
    lam_mic : array
        wavelength grid in micron
    """
    with open('wavelength_micron.inp', 'w') as f:
        write(f, len(lam_mic))  # length
        write(f, *lam_mic, sep='\n')


def write_opacity_grid(lam_mic, kappa_abs, kappa_sca=None, gfact=None, name='silicate'):
    """
    Writes out the opacity information of a grain species for RADMC3D.

    Arguments:
    ----------
    lam_mic : array
        wavelength grid in micron

    kappa_abs : array
        absorption opacity on wavelength grid lam_mic [cm^2/g]

    Keywords:
    ---------
    kappa_sca : None | array
        scattering opacity on wavelength grid lam_mic [cm^2/g]

    gfact : array
        Henyey-Greenstein factor on grid lam_mic

    name : str
        name to be appended to

    """
    nlam = len(lam_mic)

    data = np.vstack((lam_mic, kappa_abs))

    if kappa_sca is not None:
        data = np.vstack((data, kappa_sca))
    if gfact is not None:
        data = np.vstack((data, gfact))

    with open('dustkappa_{}.inp'.format(name), 'w') as f:
        write(f, 2)  # format
        write(f, nlam)  # length
        for row in data.T:
            write(f, *row)


def write_opacity_info(species=['silicate']):
    """
    Write out the opacity info file for RADMC3D.

    Keywords:
    ---------
    species : array
        For now, just the names and thermal grains are always assumed.
    """
    with open('dustopac.inp', 'w') as f:
        write(f, '2               Format number of this file')
        write(f, '{}              Nr of dust species'.format(len(species)))

        for name in species:
            write(f, '============================================================================')
            write(f, '1               Way in which this dust species is read')
            write(f, '0               0=Thermal grain')
            write(f, '{}              Extension of name of dustkappa_***.inp file'.format(name))

        write(f, '----------------------------------------------------------------------------')


def write_radmc3d_input(params={}):
    """
    Write the RADMC3D input file radmc3d.inp. This contains some defaults, but
    whatever is given as key, value pair in the dictionary `params` will overwrite
    those defaults.

    Keywrods:
    ---------
    params : dict
        parameters and values written to radmc3d.inp.
    """
    defaults = {
        'nphot': int(1e6),
        'istar_sphere': 1,
        'scattering_mode_max': 1,
        'scattering_mode': 1,
        'modified_random_walk': 1
        }

    # write possible input to the defaults

    for k, v in params.items():
        defaults[k] = v

    # write parameters to file

    maxlength = np.max([len(k) for k in defaults.keys()])
    with open('radmc3d.inp', 'w') as f:
        for k, v in defaults.items():
            write(f, k.ljust(maxlength) + ' = ' + str(v))


def get_radmc3d_arrays(disk2d, d2g, kappa_dust, nr_add=10, dr_add=0.05, showplots=False):
    """
    Reads the vertical structure from the Diskvert2d object and creates a 2D grid
    that is refined at the boundary and hopefully ready to be written out for a RADMC3D run.

    Arguments:
    ----------
    disk2d : disklab.diskvertstruct.diskvert2d
        vertical structure model from disklab

    d2g : float
        XXX TODO XXX: dust-to-gas mass ratio - should become unnecessary after
        the restructuring of the disklab code

    kappa_dust : float
        XXX TODO XXX: opacity per gram of dust, needs to be updated once the
        opacities have been restructured.

    Keywords:
    ---------
    nr_add : int
        nr of additional grid points

    dr_add: float
        fraction of inner grid point by which to extend the grid inwards

    showplots : bool
        if turned on, will produce lots of debugging plots
    """
    from scipy.interpolate import griddata
    from scipy.integrate import cumtrapz

    # GET DATA FROM OBJECT

    # cylindrical radius

    x = disk2d.r.copy()

    # Get grid arrays from verts

    Z0 = np.array([vert.z for vert in disk2d.verts])
    X0 = disk2d.r[:, None] * np.ones_like(Z0)

    # Get arrays for $\rho$, $T$, and $\tau$

    # rho_g = np.array([vert.rhogas for vert in disk2d.verts])
    # dust array (nr, nr, n_dust)
    rho0 = np.array([[dust.rho for dust in vert.dust] for vert in disk2d.verts]).swapaxes(1, 2)
    n_dust = rho0.shape[-1]

    # CREATE SPHERICAL GRID
    # create spherical radius cell centers and interfaces from cylindrical radius
    # we take the interfaces at the centers between the current cells, but then
    # recalculate the cell centers again, extrapolating the boundary interfaces

    ri1 = 0.5 * (x[1:] + x[:-1])
    ri1 = np.hstack((ri1[0] - (ri1[2] - ri1[1]), ri1,
                     ri1[-1] * ri1[-2] / ri1[-3]))
    r1 = 0.5 * (ri1[1:] + ri1[:-1])

    # Create a $\theta$-grid, just the mid-plane density value needs to be
    # adjusted - we know the mid-plane density, but we need to interpolate to
    # get the first grid point which has it's lower interface at $z=0$.

    # note: this is defined from the mid-plane up

    theta = np.arctan(disk2d.zdivr)
    thetai = 0.5 * (theta[1:] + theta[:-1])
    thetai = np.hstack((0, thetai, theta[-1] + (theta[-1] - thetai[-1])))
    theta = 0.5 * (thetai[1:] + thetai[:-1])

    # now create intermediate X and Y grids. We will refine those to smooth the inner edge

    X2_c = r1[:, None] * np.cos(theta[None, :])
    Y2_c = r1[:, None] * np.sin(theta[None, :])
    X2_i = ri1[:, None] * np.cos(thetai[None, :])
    # Y2_i = ri1[:, None] * np.sin(thetai[None, :]) # not used

    # next, since we updated the cell centers, we will interpolate the old density structure onto this new grid
    rho_sph = np.zeros([X2_c.shape[0], X2_c.shape[1], n_dust])
    points = np.array(list(zip(X0.flatten(), Z0.flatten())))
    newpoints = np.array(list(zip(X2_c.flatten(), Y2_c.flatten())))
    for idust in range(n_dust):
        values = np.log10(rho0[:, :, idust] + 1e-100).flatten()
        rho_sph[:, :, idust] = 10.**griddata(
            points, values, newpoints, fill_value=-100).reshape(len(r1), len(theta))

    # as sanity checks, we can plot the previous (cylindrical) and new (spherical) grids

    if showplots:
        f, axs = plt.subplots(2, 1, figsize=(8, 8), sharex=True, sharey=True)
        rho0_tot = rho0.sum(-1)
        vmax = np.ceil(np.log10(rho0_tot.max()))
        axs[0].pcolormesh(X0 / au, Z0 / X0, np.log10(rho0_tot + 1e-100),
                          vmin=vmax - 8, vmax=vmax, edgecolor=(1, 1, 1, 0.5), linewidth=0.1)
        axs[1].pcolormesh(X2_c / au, Y2_c / X2_c, np.log10(rho_sph.sum(-1) + 1e-100),
                          vmin=vmax - 8, vmax=vmax, edgecolor=(1, 1, 1, 0.5), linewidth=0.1)
        axs[0].set_xscale('log')
        axs[0].set_ylim(0, 0.3)
        axs[0].set_xlim(0.99 * X2_i[0, 0] / au, X2_i[20, 0] / au)

    tau1 = cumtrapz((rho0.T * kappa_dust).sum(-1), x=r1, initial=1e-100, axis=1).T

    # Smooth inner edge
    # based on rho0, the opacity, and the spherical grid, we
    # add a smoothed-off region to refine the transition from
    # optically thick to thin

    ref = refine_inner_edge(r1, ri1, rho_sph, kappa_dust, nr_add=nr_add, showplots=showplots)
    rho2 = ref['rho']
    tau2 = ref['tau']
    r2 = ref['r']
    ri2 = ref['ri']

    if showplots:

        # Plot the new density and optical depth at the mid-plane for testing

        f, ax = plt.subplots(1, 2, figsize=(10, 4), sharex=True)
        ax[0].semilogy(r1 / au, tau1[:, 0], '-x')
        ax[0].semilogy(r2 / au, tau2[:, 0], '--+')
        ax[0].set_ylim(1e-7, 1e3)
        ax[0].set_ylabel(r'$\tau$')

        ax[1].loglog(r1 / au, rho0_tot[:, 0], '-x')
        ax[1].loglog(r2 / au, rho2.sum(-1)[:, 0], '--+')
        ax[1].set_ylim(1e-10 * rho0_tot.max(), 2 * rho0_tot.max())
        ax[1].set_ylabel(r'$\rho$')

        ax[1].set_xlim(0.9 * disk2d.r[0] / au, disk2d.r[30] / au)

    # Reassign the default names

    r = r2
    ri = ri2
    rho = rho2
    rho2_tot = rho2.sum(-1)

    nphi = 1
    nr = len(r)
    nth = len(theta)

    phii = np.linspace(0, 2 * np.pi, nphi + 1)

    X_c = r[:, None] * np.cos(theta[None, :])
    Y_c = r[:, None] * np.sin(theta[None, :])
    X_i = ri[:, None] * np.cos(thetai[None, :])
    Y_i = ri[:, None] * np.sin(thetai[None, :])

    if showplots:

        xlim = [0.99 * ri[0] / au, 1.01 * ri[12] / au]
        ylim = np.array([0.0, 0.25])

        # Plot the $\tau_r$ distribution before and after adding a smoothed edge

        vmax = np.ceil(np.log10(rho2_tot.max()))
        plotgrid(
            r=r / au, ri=ri / au, theta=np.pi / 2 - theta,
            thetai=np.pi / 2 - thetai, data=np.log10(rho2_tot + 1e-100),
            xlim=xlim, ylim=ylim * X_c[0, 0] / au, zlim=[vmax - 7, vmax],
            ptype='pcolormesh', linewidth=0.1, edgecolor='face', alpha=0.5)
        ax = plt.gca()
        ax.set_facecolor('0.5')
        ax.add_artist(plt.Circle((0, 0), radius=disk2d.disk.rstar / au, ec='w', fc='y'))
        ax.set_aspect('equal')
        ax.set_title('new density grid')

        plotmesh(ri=ri, thetai=np.pi / 2 - thetai, r=r, theta=np.pi / 2 - theta, scale=au)
        ax = plt.gca()
        ax.axhline(0, c='r')
        ax.add_artist(plt.Circle((0, 0), radius=disk2d.disk.rstar / au, ec='w', fc='y'))
        ax.set_xlim(xlim)
        ax.set_ylim(ylim * X_c[0, 0] / au)
        ax.set_aspect('equal')
        ax.set_title('new grid')

        f, axs = plt.subplots(2, 1, figsize=(10, 8), sharex=True, sharey=True)
        cc1 = axs[0].pcolormesh(
            X0 / au, Z0 / X0, np.log10(tau1 + 1e-100),
            vmin=-1, vmax=1, cmap='RdGy', edgecolor=(1, 1, 1, 0.5), lw=0.1)
        cc2 = axs[1].pcolormesh(
            X_c / au, Y_c / X_c, np.log10(tau2 + 1e-100),
            vmin=-1, vmax=1, cmap='RdGy', edgecolor=(1, 1, 1, 0.5), lw=0.1)
        for ax in axs:
            ax.set_ylim(ylim)
            ax.set_xlim(xlim)
            ax.set_ylabel('$z/r$')

        ax.set_xlabel('$r$ [au]')

        cb1 = plt.colorbar(cc1, ax=axs[0])
        cb2 = plt.colorbar(cc2, ax=axs[1])
        cb1.set_label(r'$\log(\tau_r)$ ')
        cb2.set_label(r'$\log(\tau_r)$ ')
        f.subplots_adjust(hspace=0.05, wspace=0.05)

    # return the new grid and density structure

    return {
        'r': r,
        'ri': ri,
        'theta': theta,
        'thetai': thetai,
        'phii': phii,
        'xc': X_c,
        'xi': X_i,
        'yc': Y_c,
        'yi': Y_i,
        'rho': rho,
        'nr': nr,
        'nphi': nphi,
        'nth': nth
        }


def refine_inner_edge(r, ri, rho, kappa_dust, nr_add=10, showplots=False):
    """
    Takes a spherical 2D grid and adds a softened refined inner edge to
    trace the transition from optically thick to thin.

    r : array
        spherical radius grid: cell center

    ri : array
        spherical radius grid: cell interfaces

    rho : array
        spherical density grid (nr, ntheta, ndust), itheta=0 is mid-plane

    kappa_dust : float | array of same shape as rho
        dust opacity as cm^2/g XXX needs update if the rewrite of opacities
        is finished

    nr_add : int
        number of additional inner grid cells for refinement

    showplots : bool
        whether to show debuggin plots

    Output:
    -------
    dictionary containing the following items

    r : array
        new cell center grid, len(r) = nr = (nr_initial + nr_add)

    ri : array
        new cell interface grid, len(ri) = nr + 1

    rho : array
        new density grid, shape(ri) = [nr,ntheta,ndust]

    tau : array
        new radial optical depth grid, shape(ri) = [nr,ntheta]
    """
    from scipy.integrate import cumtrapz
    # calculate tau_r at the mid-plane

    tau1 = cumtrapz((rho.T * kappa_dust).sum(-1), x=r, initial=1e-100, axis=1).T

    # Add grid points and a steeply declining density extrapolation to smooth the transition

    i_ref = tau1[:, 0].searchsorted(1)  # inside of which cell to refine

    # calculate a fine linear grid (interfaces and centers) inside the inner interface

    ri_add = np.linspace(ri[i_ref] * (1 - 0.05), ri[i_ref], nr_add + i_ref)
    r_add = 0.5 * (ri_add[1:] + ri_add[:-1])

    # add a radially exponentially dropping density

    rho_add = np.exp(
        (r_add - r_add[-1]) / (r_add[-1] - r_add[-2]))[:, None, None] * rho[i_ref, :, :]

    # create the extended grids, that is, i.e. fine linear grid + old grid

    r2 = np.hstack((r_add, r[i_ref:]))
    ri2 = np.hstack((ri_add, ri[i_ref + 1:]))
    # rho2 = np.vstack((rho_add, rho[i_ref:, :]))
    rho2 = np.concatenate((rho_add, rho[i_ref:, ...]), axis=0)

    # calculate the radial optical depth on that grid

    tau2 = cumtrapz(rho2.T * kappa_dust, x=r2, initial=1e-100, axis=1).T

    if showplots:

        xlim = [0.99 * ri2[0] / au, 1.01 * ri2[nr_add + 2] / au]

        # show the old grid, the linear extension grid,
        # and the new combined grid

        f, ax = plt.subplots()
        ax.plot(r / au, 1.2 * np.ones_like(r), 'o', c='C0')
        ax.plot(ri / au, 1.2 * np.ones_like(ri), '+', c='C0')
        ax.plot(r_add / au, 1.0 * np.ones_like(r_add), 'o', c='C1')
        ax.plot(ri_add / au, 1.0 * np.ones_like(ri_add), '+', c='C1')
        ax.plot(r2 / au, 0.8 * np.ones_like(r2), 'o', c='C2')
        ax.plot(ri2 / au, 0.8 * np.ones_like(ri2), '+', c='C2')
        ax.set_xlim(xlim)
        ax.set_ylim(0.5, 1.5)

    return {'r': r2, 'ri': ri2, 'rho': rho2, 'tau': tau2}
