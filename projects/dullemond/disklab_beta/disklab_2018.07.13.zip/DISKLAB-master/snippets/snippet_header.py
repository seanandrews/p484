#
# WHAT THIS SNIPPET_HEADER.PY IS MEANT FOR:
#
# This snippet_header.py file is only meant to make the snippet examples
# of DISKLAB a bit less cluttered with the usual import statements. But
# you can easily replace this with some (or all) of the statements below
# (with the exception of the stuff below the '----').
#
# For instance, the following three imports are the standard imports
# of most python scripts: os, numpy and plotting
#
import os
import numpy as np
import matplotlib.pyplot as plt
#
# And the following are imports from DISKLAB. Here they are all
# imported, but usually you need only a few of them, depending on
# which functionality of DISKLAB you want to use.
#
# For the 1-D radial models you need the DiskModel class:
#
from disklab import DiskModel
#
# If you want to add dust into the 1-D radial disk models, you need:
#
from disklab import DiskComponent
#
# If you want to model 1-D vertical disk structure models, you need
# the DiskVertModel class:
#
from disklab import DiskVertModel
#
# And if you want to add dust into those, you need:
#
from disklab import DiskVertComponent
#
# If you want to do 2-D (radial-vertical) disk models, you need the
# DiskVert2D class:
#
from disklab import DiskVert2D
#
# If you want to include details of the dust grain physics, you need:
#
from disklab import GrainModel
#
# If your disk model needs information about mean opacities, you need:
#
from disklab.meanopacity import evaluate_meanopacity
#
# And for your convenience, here are some natural constants (year,
# astronomical unit, solar mass, earth mass, Boltzmann constant,
# proton mass and solar luminosity):
#
from disklab.natconst import year, au, MS, Mea, kk, mp, LS
#
# this one is used to read command line parameters for executing the snippets
# non-interactively.
#
import argparse

# for backward compatibility with matplotlib<2.0.0, we define our own color list
# to be used instead of a color_cycler, this should work like a periodic list


class Colors(list):
    colorlist = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728',
                 '#9467bd', '#8c564b', '#e377c2', '#7f7f7f',
                 '#bcbd22', '#17becf']

    def __init__(self, colorlist=colorlist):
        self.colorlist = colorlist

    def __getitem__(self, i):
        return self.colorlist[i % len(self.colorlist)]


colors = Colors()

# define which parts should be imported upon `from snippet_header import *`

__all__ = ['np',
           'plt',
           'DiskModel',
           'is_interactive',
           'year',
           'au',
           'MS',
           'Mea',
           'kk',
           'mp',
           'LS',
           'DiskComponent',
           'DiskVert2D',
           'DiskVertModel',
           'DiskVertComponent',
           'GrainModel',
           'evaluate_meanopacity',
           'colors'
           ]

#
# ---------------------------------------------------------------
# THE STUFF BELOW IS ONLY FOR THE AUTOMATIC RUNNING OF ALL
# SNIPPETS FOR THE AUTOMATIC TUTORIAL GENERATION.
#
# When you use or modify the snippets yourself, you can replace the
# command finalize() by plt.show(). You do not really need the
# finalize() command.
# ---------------------------------------------------------------
#
RTHF   = argparse.RawTextHelpFormatter
PARSER = argparse.ArgumentParser(description=__doc__, formatter_class=RTHF)
PARSER.add_argument('-n', '--nonstop', help='do not show the plots, instead proceed', action='store_true', default=False)
ARGS  = PARSER.parse_args()


def is_interactive():
    """
    Returns true if script is run interactively, or
    if
    """
    import __main__ as main

    return not hasattr(main, '__file__')


def finalize(figures=None):
    """
    Run this at the end of every snippet:

    IF
        script is run interactively
    OR
        script is run from command line with option `-i`
    THEN:
        plt.show()

    ELSE:
        save all figures (or the ones that are passed to this function)
        if no figures should be saved: pass an empty list.

    Keywords:
    ---------

    figures : None | list
        list: all figure handles to be saved, none are saved if list is empty
        None: saves all figures

    """
    from __main__ import __file__

    # get all figure numbers (or the ones given as argument)

    if figures is None:
        fignums = plt.get_fignums()
    elif figures is []:
        return 0
    else:
        fignums = [f.number for f in figures]

    # either show the figures, or save them as PDFs

    if not ARGS.nonstop:
        plt.show()
    else:
        for i in fignums:
            fname = 'fig_' + os.path.basename(__file__).replace('.py', '_{}.pdf'.format(i))
            print('saving {}'.format(fname))
            plt.figure(i).savefig(fname)
