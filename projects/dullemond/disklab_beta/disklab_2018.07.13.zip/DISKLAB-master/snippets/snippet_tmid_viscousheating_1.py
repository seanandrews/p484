from snippet_header import DiskModel, plt, MS, au, finalize

d = DiskModel(mdisk=0.01 * MS)
d.add_dust(agrain=1e-4)
kappa = 1e3
d.meanopacitymodel = ['supersimple', {'dusttogas': 0.01, 'kappadust': kappa}]
d.compute_mean_opacity()
d.compute_disktmid(vischeat=True)

plt.figure()
plt.plot(d.r / au, d.tmid, label='Mid')
plt.plot(d.r / au, d.tirr, label='Irradd')
plt.plot(d.r / au, d.tvisc, label='Viscous')
plt.xscale('log')
plt.yscale('log')
plt.xlim(xmax=200)
plt.xlabel('r [au]')
plt.ylabel(r'$T_{\mathrm{mid}}$')
plt.legend()

finalize()
