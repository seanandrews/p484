from disklab.diskmodel import *
from disklab.natconst import *
import matplotlib.pyplot as plt
tstart = 1e3*year
tend   = 3e6*year
ntime  = 10
nr     = 100
nspec  = 2
time   = tstart * (tend/tstart)**(np.linspace(0.,1.,ntime+1))
d      = diskmodel(rout=1000*au,nr=nr)
d.make_disk_from_simplified_lbp(1e3,10*au,1)
d.multi_allocate_dustspecies(nspec)
d.multi_choose_dustspec(0)
d.add_dust(agrain=1e-4,dtg=0.1e-2)
d.multi_choose_dustspec(1)
d.add_dust(agrain=1e-1,dtg=0.9e-2)
plt.plot(d.r/au,d.multi_sigdust[0,:])
plt.plot(d.r/au,d.multi_sigdust[1,:],'--')
for itime in range(1,ntime+1):
   dt = time[itime]-time[itime-1]
   d.compute_viscous_evolution_next_timestep(dt)
   for ispec in range(nspec):
      d.multi_choose_dustspec(ispec)
      d.compute_dust_radial_drift_next_timestep(dt)
   plt.plot(d.r/au,d.multi_sigdust[0,:])
   plt.plot(d.r/au,d.multi_sigdust[1,:],'--')
plt.xscale('log')
plt.yscale('log')
plt.ylim(1e-6,1e3)
plt.xlabel('r [au]')
plt.ylabel(r'$\Sigma_d$')
#plt.savefig('fig_snippet_multi_dustdrift_1_1.pdf')
plt.show()
