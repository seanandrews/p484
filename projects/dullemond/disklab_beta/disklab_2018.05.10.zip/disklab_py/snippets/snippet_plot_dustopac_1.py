from disklab.grainmodel import *
from disklab.natconst import *
import matplotlib.pyplot as plt

grain = grainmodel()
grain.read_opacity('dustkappa_silicate.inp')

plt.figure()
plt.plot(grain.opac_lammic,grain.opac_kabs,label='Absorption')
plt.plot(grain.opac_lammic,grain.opac_ksca,label='Scattering')
plt.xlabel(r'$\lambda [\mu\mathrm{m}]$')
plt.ylabel(r'$\kappa [\mathrm{cm}^2/\mathrm{g}]$')
plt.xscale('log')
plt.yscale('log')
plt.xlim(1e-1,1e4)
plt.ylim(ymin=1e-3)
plt.legend(loc='upper right')
#plt.savefig('fig_snippet_plot_dustopac_1_1.pdf')
plt.show()
