from disklab.diskmodel import *
from disklab.natconst import *
import matplotlib.pyplot as plt
d=diskmodel(mdot=1e-8*MS/year,rin=10*au,rout=30*au,nr=1000)
rbump=20.*au                         # Radial location of bump
abump=1.0                            # Amplitude of bump (relative)
hpbump=np.interp(rbump,d.r,d.hp)     # Pressure scale height
wbump=0.5*hpbump                     # Width (stand dev) of Gaussian bump
fact=1+abump*np.exp(-0.5*((d.r-rbump)/wbump)**2)
d.sigma *= fact
d.rhomid *= fact
d.compute_solberg_hoiland(vertint=True)  # Compute SH with Sigma and P=Sigma*c_s^2
SHsqdimless = d.SHsq / d.omk**2      # SH freq in units of Kepler freq
plt.plot(d.r/au,SHsqdimless)
plt.xlabel(r'$r [\mathrm{au}]$')
plt.ylabel('SH frequency [Kepler]')
#plt.savefig('fig_snippet_deviation_kepler_2_1.pdf')
plt.show()
