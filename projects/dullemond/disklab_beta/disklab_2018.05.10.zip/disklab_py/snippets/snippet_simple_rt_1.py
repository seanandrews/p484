from disklab.diskmodel import *
from disklab.natconst import *
import matplotlib.pyplot as plt
d1 = diskmodel(flang=0.05)
flang = 0.05*(d1.r/au)**(2./7.)
d2 = diskmodel(flang=flang)
plt.plot(d1.r/au,d1.tmid,label='flang=0.05')
plt.plot(d2.r/au,d2.tmid,label='flang=0.05*(r/au)^(2/7)')
plt.legend()
plt.xlabel(r'$r [\mathrm{au}]$')
plt.ylabel(r'$T [\mathrm{K}]$')
plt.xscale('log')
plt.yscale('log')
#plt.savefig('fig_snippet_simple_rt_1_1.pdf')
plt.show()
