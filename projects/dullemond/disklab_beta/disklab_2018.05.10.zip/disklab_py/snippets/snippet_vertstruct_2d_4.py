from disklab.diskvertstruct import *
from disklab.natconst import *
import matplotlib.pyplot as plt
import copy
mstar  = 1*MS
lstar  = 1*LS
sig0   = 10.
r0     = 50.*au
dtg    = 0.01
kapdst = 1e2
flang  = 0.025
zrmax  = 1.0
nr     = 100
rin    = 1*au
rout   = 500*au
alpha  = 1e-6
opac   = ['supersimple',{'dusttogas':0.01,'kappadust':1e2}]
disk   = diskmodel(mstar=mstar,lstar=lstar,nr=nr,rin=rin,rout=rout,alpha=alpha)
disk.make_disk_from_simplified_lbp(sig0,r0,0.5)
disk2d = diskvert2d(disk,zrmax=zrmax,meanopacitymodel=opac)

for vert in disk2d.verts:
    vert.iterate_vertical_structure()

disk11d= copy.deepcopy(disk2d)

maxiter = 10
for iter in range(maxiter):
    print("Vertical structure iteration {}".format(iter))
    for vert in disk2d.verts:
        vert.compute_mean_opacity()
    disk2d.radial_raytrace()
    disk2d.solve_2d_rad_diffusion(linsol_convcrit=1e-6,linsol_itermax=2000, \
                                  nonlin_convcrit=1e-3,nonlin_itermax=20)
    for vert in disk2d.verts:
        vert.compute_rhogas_hydrostatic()

xcoord = np.log10(disk2d.r/au)
ycoord = pi/2-disk2d.theta
extent = [xcoord.min(),xcoord.max(),ycoord.min(),ycoord.max()]
skip   = 4
sl1d   = slice(None,None,skip)
sl2d   = (slice(None,None,skip),slice(None,None,-skip))

plt.figure()
plt.imshow(np.log10(disk2d.src[:,:,0].T+1e-30),extent=extent,aspect='auto')
plt.xlabel(r'$^{10}\log(r/\mathrm{au})$')
plt.ylabel(r'$z/r$')
plt.title('Source term')
plt.colorbar()
plt.show()
plt.savefig('fig_snippet_vertstruct_2d_4_1.pdf')
plt.figure()
plt.imshow(np.log10(disk2d.temp[:,:,0].T),extent=extent,aspect='auto')
plt.xlabel(r'$^{10}\log(r/\mathrm{au})$')
plt.ylabel(r'$z/r$')
plt.title('Temperature')
plt.colorbar()
plt.show()
plt.savefig('fig_snippet_vertstruct_2d_4_2.pdf')
plt.figure()
plt.plot(disk2d.disk.r/au,disk2d.temp[:,99,0])
plt.plot(disk2d.disk.r/au,disk2d.temp[:,0,0])
plt.ylabel('T [K]')
plt.xlabel('r [au]')
plt.xscale('log')
plt.yscale('log')
plt.show()
plt.savefig('fig_snippet_vertstruct_2d_4_3.pdf')
plt.figure()
plt.plot(disk2d.disk.r/au,disk2d.fld_jmean[:,99,0])
plt.plot(disk2d.disk.r/au,disk2d.fld_jmean[:,0,0])
plt.ylabel('J')
plt.xlabel('r [au]')
plt.xscale('log')
plt.yscale('log')
plt.show()
plt.savefig('fig_snippet_vertstruct_2d_4_4.pdf')
plt.figure()
plt.imshow(np.log10(disk2d.fld_jmean[:,:,0].T),extent=extent,aspect='auto')
plt.xlabel(r'$^{10}\log(r/\mathrm{au})$')
plt.ylabel(r'$z/r$')
dirvec_r =  disk2d.fld_hflux[0][:,:,0]/disk2d.fld_jmean[:,:,0]
dirvec_t = -disk2d.fld_hflux[1][:,:,0]/disk2d.fld_jmean[:,:,0]
plt.quiver(xcoord[sl1d],ycoord[sl1d], dirvec_r[sl2d].T, dirvec_t[sl2d].T, units='xy')
plt.title('Mean intensity and vec H/J')
plt.show()
plt.savefig('fig_snippet_vertstruct_2d_4_5.pdf')
plt.figure()
plt.imshow(np.log10(disk2d.fld_limiter[:,:,0].T),extent=extent,aspect='auto')
plt.xlabel(r'$^{10}\log(r/\mathrm{au})$')
plt.ylabel(r'$z/r$')
plt.title('Flux limiter')
plt.colorbar()
plt.show()
plt.savefig('fig_snippet_vertstruct_2d_4_6.pdf')


