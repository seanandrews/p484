from disklab.diskvertstruct import *
from disklab.natconst import *
import matplotlib.pyplot as plt
import copy
mstar  = 1*MS
lstar  = 1*LS
r      = 1*AU
siggas = 1700.
dtg    = 0.01
kapdst = 1e2
flang  = 0.05
zrmax  = 0.2
opac   = ['supersimple',{'dusttogas':0.01,'kappadust':1e2}]
dtg    = 0.01
agrain = 1e0
xigrain= 3.0
alpha  = 1e-3
time   = np.array([0.,1e0,1e1,1e2,1e3,1e4,1e5])*year
ntime  = time.size
vert   = diskvertmodel(mstar,r,siggas,flang=flang,zrmax=zrmax, \
                       lstar=lstar,meanopacitymodel=opac,alphavisc=alpha)
vert.iterate_vertical_structure()
dstvert= diskvertcomponent(vert,dtg,agrain=agrain,xigrain=xigrain)
plt.figure()
plt.plot(vert.z/vert.r,vert.rhogas,label='gas')
for it in range(ntime-1):
    dtime = time[it+1]-time[it]
    dstvert.timestep_settling_mixing(dtime)
    plt.plot(vert.z/vert.r,dstvert.rho,label='dust t={0:8.1e} yr'.format(time[it+1]/year))
plt.xlabel('z/r')
plt.yscale('log')
plt.ylim(ymin=1e-36)
plt.legend(loc='lower left')
plt.ylabel(r'$\rho [\mathrm{g}/\mathrm{cm}^3]$')
#plt.savefig('fig_snippet_vertstruct_dustsett_1_1.pdf')
plt.show()
