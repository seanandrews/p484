from disklab.diskmodel import *
from disklab.natconst import *
import matplotlib.pyplot as plt
import copy
mstar  = MS         # Stellar mass
xigrain= 2.0        # Material density
alpha  = 1e-3       # Viscous alpha
tstart = 1e2*year
tend   = 3e5*year
ntime  = 100
agrain = 1e0        # Grain size in cm
dtg0   = 1e-2       # Initial dust-to-gas ratio
#
# Make grid with a refined region
# 
nrin   = 200
nrmid  = 1000
nrout  = 200
rin    = 1*au
r1     = 48.*au
r2     = 52.*au
rout   = 1e3*au
rinner = rin * (r1/rin)**np.linspace(0,1,nrin)
rmid   = r1 * (r2/r1)**np.linspace(0,1,nrmid)
router = r2 * (rout/r2)**np.linspace(0,1,nrout)
r      = np.hstack((rinner[:-1],rmid[:-1],router))
#
# Define and make the disk model
#
rdisk0 = 60*au
sig0   = 1e1        # Surface density of the disk at rdisk0 in g/cm^2
flang  = 0.05       # Flaring angle of the disk (fixed as a parameter)
lam    = 0.13       # Band 6 of ALMA
time   = tstart * (tend/tstart)**(np.linspace(0.,1.,ntime+1))
d      = diskmodel(rgrid=r,flang=flang,alpha=alpha)
d.make_disk_from_simplified_lbp(sig0,rdisk0,1)
#
# Add a bump
#
rbump  = 50.*au                         # Radial location of bump
abump  = 2.0                            # Amplitude of bump (relative)
hpbump = np.interp(rbump,d.r,d.hp)      # Pressure scale height
wbump  = 1.0*hpbump                     # Width (stand dev) of Gaussian bump
wave   = -abump*np.exp(-0.5*((d.r-rbump)/wbump)**2)
d.alpha *= np.exp(wave)
#
# Add this dust to the model
#
sigmadust_array = np.zeros((ntime+1,len(d.r)))
tau_array = np.zeros((ntime+1,len(d.r)))
d.add_dust(agrain=agrain,xigrain=xigrain,dtg=dtg0)
d.dust[0].grain.compute_simple_opacity(lam=lam,tabulatemean=False)
kappa = d.dust[0].grain.opac_kabs[0]
sigmadust_array[0,:] = d.dust[0].sigma.copy()
tau_array[0,:] += d.dust[0].sigma[:]*kappa
for itime in range(1,ntime+1):
   dt = time[itime]-time[itime-1]
   d.compute_viscous_evolution_and_dust_drift_next_timestep(dt)
   sigmadust_array[itime,:] = d.dust[0].sigma.copy()
   tau_array[itime,:] += d.dust[0].sigma[:]*kappa
#
# Find the pressure peak position 
#
q  = d.rhomid*d.tmid
ir = np.where(np.logical_and(d.r>rbump-wbump,d.r<rbump+wbump))
rr = d.r[ir]
qq = q[ir]
ir = np.where(qq==qq.max())[0][0]
rpeak = rr[ir]
#
# Since the pressure peak != surface density peak != peak of the Gauss,
# the width of the pressure peak is also not exactly the same as that
# of the Gaussian bump. So let us determine the width by computing the
# second derivative. 
#
pmid  = d.rhomid*d.cs**2
dp    = d.compute_radial_derivative(pmid)
dp2   = d.compute_radial_derivative(dp)
wpeak = 1./np.sqrt(-np.interp(rpeak,d.r,dp2/pmid))
#
# Now we can compute the analytic solution
#
Stbump= np.interp(rpeak,d.r,d.dust[0].St)
Sc    = 1.0
wdust = wpeak * np.sqrt(d.alpha.min()/(Sc*Stbump))
assert wdust<wpeak, "Analytic solution invalid"
sigdb = np.interp(rpeak,d.r,d.dust[0].sigma)
sigd  = sigdb*np.exp(-(d.r-rpeak)**2/(2*wdust**2))
#
# Plots of final state
#
plt.figure(1)
d.plot(d.dust[0].sigma,ylabel=r'$\Sigma_d$',xmin=(rpeak-0.1*wpeak)/au,xmax=(rpeak+0.1*wpeak)/au,xlog=False,ylog=False,label='numeric')
d.plot(sigd,oplot=True,label='analytic')
plt.legend()
plt.show()
