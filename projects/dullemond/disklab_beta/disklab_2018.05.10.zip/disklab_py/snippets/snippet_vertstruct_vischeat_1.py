from disklab.diskvertstruct import *
from disklab.natconst import *
import matplotlib.pyplot as plt
import copy
mstar  = 1*MS
lstar  = 1*LS
r      = 1*AU
siggas = 1700.
dtg    = 0.01
kapdst = 1e2
flang  = 0.05
zrmax  = 0.2
alpha  = 1e-3
opac   = ['supersimple',{'dusttogas':0.01,'kappadust':1e2}]
vert   = diskvertmodel(mstar,r,siggas,flang=flang,zrmax=zrmax, \
                       lstar=lstar,meanopacitymodel=opac,      \
                       alphavisc=alpha)
vert.iterate_vertical_structure()
plt.figure()
plt.plot(vert.z/vert.r,vert.rhogas)
plt.xlabel('z/r')
plt.yscale('log')
plt.ylabel(r'$\rho [\mathrm{g}/\mathrm{cm}^3]$')
#plt.savefig('fig_snippet_vertstruct_vischeat_1_1.pdf')
plt.figure()
plt.plot(vert.z/vert.r,vert.tgas)
plt.xlabel('z/r')
plt.ylabel(r'$T [K]$')
plt.ylim(ymin=0)
#plt.savefig('fig_snippet_vertstruct_vischeat_1_2.pdf')
plt.show()
