"""
Setup file for package `disklab`.
"""
from numpy.distutils.core import Extension, setup
from setuptools import find_packages
import os
import warnings

try:
    setup(name='disklab',
          description='circumstellar disk model and helper routines',
          long_description=open(os.path.join(
              os.path.dirname(__file__), 'README.md')).read(),
          url='https://github.com/dullemond/DISKLAB',
          author='Kees Dullemond & Til Birnstiel',
          author_email='dullemond_AT_uni-heidelberg.de & til.birnstiel_AT_lmu.de',
          license='GPLv3',
          packages=find_packages(),
          include_package_data=True,
          install_requires=['astropy', 'scipy', 'numpy', 'matplotlib'],
          zip_safe=False,
          ext_modules=[
              Extension(name='disklab.diffusion', sources=[
                  'disklab/diffusion.f90']),
              ],
          )
except:
    warnings.warn('Failed building the 2D extensions - will install DISKLAB without them. See users guide for installing them manually.')
    setup(name='disklab',
          description='circumstellar disk model and helper routines',
          long_description=open(os.path.join(
              os.path.dirname(__file__), 'README.md')).read(),
          url='https://github.com/dullemond/DISKLAB',
          author='Kees Dullemond & Til Birnstiel',
          author_email='dullemond_AT_uni-heidelberg.de & til.birnstiel_AT_lmu.de',
          license='GPLv3',
          packages=find_packages(),
          include_package_data=True,
          install_requires=['astropy', 'scipy', 'numpy', 'matplotlib'],
          zip_safe=False,
          ext_modules=[],
          )
