import numpy as np
from scipy.interpolate import interp1d
from scipy import optimize
from . import natconst as nc
from .grainmodel import *
from .solvediffonedee import *
from .diskmodel import *
import copy
import warnings
try:
    from .solvediff3d import *
except:
    warnings.warn("Importing diskvertstruct was successful, but 2D radiative diffusion not available, because diffusion.f90 has not been compiled to diffusion.so. All other methods of diskvertstruct.py remain available. For full functionality type make in disklab directory, which should produce the diffusion.so library using f2py.")


class diskvertmodel(object):
    """
    This is a 1-D vertical model of a protoplanetary disk, i.e. at a given radius in the disk.
    The vertical coordinate is treated in the z<<r limit, i.e. no geometric terms due to
    spherical vs cylindrical coordinate are taken into account.

    ARGUMENTS:
    mstar             Stellar mass [g]
    r                 Radius at which the vertical model is located [cm]
    siggas            Surface density of the gas [g/cm^2]

    OPTIONAL ARGUMENTS:
    nz                Nr of vertical grid points from the midplane to the top
    zrmaz             Upper z of the grid in units of r, i.e. maximum z/r of the grid
    zgrid             Alternative to nz and zrmax you can also give the z grid yourself
    lstar             Stellar luminosity [erg/s]
    flidx             Flaring irradiation index such that flaring angle is flang = flidx * z / r
    meanopacitymodel  The mean opacity model
    mugas             The mean molecular weight in units of mp
    gamma             The ratio of specific heats
    alphavisc         The viscous alpha parameter
    """

    def __init__(self,mstar,r,siggas,nz=100,zrmax=0.4,zgrid=None,lstar=nc.LS,flidx=None, \
                 flang=None,meanopacitymodel=None,mugas=2.3,gamma=(7./5.),alphavisc=None,Sc=1.0):
        #
        # Create the grid
        #
        assert np.isscalar(r), "Error: diskvertmodel only works for a single radius."
        self.r      = r    # Warning: do not change this after __init__. Better make new diskvertmodel.
        if zgrid is None:
            self.z  = np.linspace(0.,zrmax*r,nz)
        else:
            self.z  = zgrid.copy()
        zmax        = self.z.max()
        zi          = 0.5 * ( self.z[1:] + self.z[:-1] )
        zi          = np.hstack((0.,zi,zmax))
        self.dz     = zi[1:] - zi[:-1]
        #
        # Copy the relevant quantities into the object
        #
        self.mstar  = mstar
        self.siggas = siggas
        self.lstar  = lstar
        if flidx is not None and flang is not None:
            raise ValueError("Cannot specify both flaring index and flaring angle.")
        if flidx is None and flang is None:
            self.flidx = 0.1
        else:
            if flidx is not None:
                self.flidx  = flidx
            if flang is not None:
                self.flang  = flang
        if alphavisc is not None:
            self.alphavisc = alphavisc
        #
        # Some defaults
        #
        self.mugas  = mugas
        self.gamma  = gamma
        self.Sc     = Sc
        #
        # Some computations
        #
        self.omk    = np.sqrt(nc.GG*self.mstar/self.r**3)
        #
        # First guess of structure
        #
        if flang is None:
            flang = 0.05
        tgas = ( 0.5 * flang * self.lstar / ( nc.ss * 4 * nc.pi * self.r**2 ) )**0.25
        self.compute_rhogas_isothermal(tgas)
        #
        # Opacity model
        #
        if meanopacitymodel is not None:
            self.meanopacitymodel = meanopacitymodel
            self.compute_mean_opacity()

    def vertically_integrate(self,rho):
        """
        Integrate some density-like quantity rho vertically, to obtain a surface density-like
        quantity. We of course multiply by 2 due to the upper/lower part of the disk.
        """
        q           = rho*self.dz
        return 2*q.sum()

    def compute_rhogas_isothermal(self,tgas):
        """
        Set up the gas density according to a vertically isothermal hydrostatic equilibrium.
        """
        assert np.isscalar(tgas), "For isothermal model, tgas must be vertically constant"
        self.tgas   = np.ones_like(self.z) * tgas
        cs          = np.sqrt(nc.kk*tgas/(self.mugas*nc.mp))
        hp          = cs/self.omk
        self.rhogas = np.exp(-0.5*self.z**2/hp**2)
        dum         = self.vertically_integrate(self.rhogas)
        self.rhogas = self.rhogas * self.siggas / dum

    def compute_rhogas_hydrostatic(self):
        """
        Compute the rhogas according to hydrostatic equilibrium, for a given temperature
        structure. Before calling, you must have specified self.tgas: an array of gas
        temperature as a function of z.
        """
        assert hasattr(self,'tgas'), "Error: Can only compute hydrostatic equilibrium if temperature tgas is given as an array."
        if np.isscalar(self.tgas):
            self.tgas = np.ones_like(self.z) * self.tgas
        if not hasattr(self,'rhogas'): self.rhogas = np.zeros_like(self.z)
        omk2        = self.omk**2
        gravc       = omk2*self.mugas*nc.mp/nc.kk
        temp        = self.tgas
        z           = self.z
        zi          = 0.5 * ( z[1:] + z[:-1] )
        dzi         = z[1:] - z[:-1]
        rho         = self.rhogas
        rho[0]      = 1.0
        for iz in range(len(self.z)-1):
            dlgt      = (np.log(temp[iz+1])-np.log(temp[iz])) / dzi[iz]
            grv       = 0.5 * gravc * ( z[iz+1]/temp[iz+1] + z[iz]/temp[iz] )
            rho[iz+1] = rho[iz] * np.exp( -dzi[iz]*(grv+dlgt) )
        dum         = self.vertically_integrate(self.rhogas)
        self.rhogas = self.rhogas * self.siggas / dum

    def compute_rhogas_hydrostatic_adiabatic(self,tol=1e-10,maxiter=100):
        """
        As compute_rhogas_hydrostatic(), but now we first compute the specific
        entropy at each point, then put that on a mass-coordinate (i.e. fixed
        to the gas packet), then iterate. Essentially this readjusts the density
        to a hydrostatic equilibrium but it does so in an adiabatic manner.
        """
        assert hasattr(self,'tgas'), "Error: Can only compute hydrostatic equilibrium if temperature tgas is given as an array."
        if np.isscalar(self.tgas):
            self.tgas = np.ones_like(self.z) * self.tgas
        if not hasattr(self,'rhogas'): self.rhogas = np.zeros_like(self.z)
        #
        # Get the grid
        #
        z           = self.z
        nz          = len(z)
        dz          = self.dz
        zi          = 0.5 * ( z[1:] + z[:-1] )
        dzi         = z[1:] - z[:-1]
        #
        # Compute the specific entropy everywhere
        #
        self.compute_specific_entropy_from_tgas()
        entropy     = self.specific_entropy
        entropyi    = np.hstack((entropy[0],0.5*(entropy[1:]+entropy[:-1]),entropy[nz-1]))
        #
        # Compute the column density coordinate
        #
        nz          = len(self.z)
        coldensi    = np.zeros(nz+1)
        for iz in range(nz-1,-1,-1):
            coldensi[iz] = coldensi[iz+1] + self.dz[iz] * self.rhogas[iz]
        if np.abs(2*coldensi[0]/self.siggas-1.0) > 1e-3:
            raise ValueError('Error: Column density of rhogas unequal to siggas.')
        #
        # Now compute the new hydrostatic balance
        #
        omk2        = self.omk**2
        gravc       = omk2*self.mugas*nc.mp/nc.kk
        temp        = self.tgas
        rho         = self.rhogas
        tprev       = self.tgas.copy()
        for iter in range(maxiter):
            #
            # Do a hydrostatic equilibrium integration
            #
            rho[0]      = 1.0
            for iz in range(len(self.z)-1):
                dlgt      = (np.log(temp[iz+1])-np.log(temp[iz])) / dzi[iz]
                grv       = 0.5 * gravc * ( z[iz+1]/temp[iz+1] + z[iz]/temp[iz] )
                rho[iz+1] = rho[iz] * np.exp( -dzi[iz]*(grv+dlgt) )
                dum       = self.vertically_integrate(self.rhogas)
                rho[:]   *= self.siggas / dum
            #
            # Compute the new column density
            #
            coldensnew    = np.zeros(nz)
            coldensnew[-1]= 1e-90
            for iz in range(nz-2,-1,-1):
                coldensnew[iz] = coldensnew[iz+1] + 0.5 * ( dz[iz+1]*rho[iz+1] + dz[iz]*rho[iz] )
            coldensnew[0] = (1.0-1e-14)*coldensi[0]
            #
            # Map the specific entropy back to the z-grid
            #
            entropy[:] = np.interp(-coldensnew,-coldensi,entropyi)
            #
            # Compute the new temperature
            #
            self.compute_tgas_from_specific_entropy()
            #
            # Check error
            #
            error = np.abs((self.tgas-tprev)/(self.tgas+tprev)).max()
            if error<tol: break
            tprev = self.tgas.copy()
        self.iter=iter

    def compute_specific_entropy_from_tgas(self):
        """
        Thermodynamic function computing the specific entropy s from the gas temperature tgas.
        """
        if not hasattr(self,'specific_entropy'): self.specific_entropy = np.zeros_like(self.z)
        rhogas = self.rhogas
        gamma  = self.gamma
        mugas  = self.mugas
        tgas   = self.tgas
        s      = self.specific_entropy
        pgas   = rhogas * tgas * nc.kk / ( mugas * nc.mp )
        K      = pgas / rhogas**gamma
        s[:]   = ( nc.kk / ( mugas * (gamma-1) ) ) * np.log(K)

    def compute_tgas_from_specific_entropy(self):
        """
        Thermodynamic function computing the gas temperature from the specific entropy s
        """
        rhogas = self.rhogas
        gamma  = self.gamma
        mugas  = self.mugas
        s      = self.specific_entropy
        tgas   = self.tgas
        K      = np.exp( ( ( mugas * (gamma-1) ) / nc.kk ) * s )
        pgas   = K*rhogas**gamma
        tgas[:]= (pgas/rhogas)*(mugas*nc.mp/nc.kk)

    def compute_mean_opacity(self,meanopacitymodel=None):
        """
        To compute the radiative heating and cooling of a protoplanetary disk, we need
        the opacity of the disk material. This is most likely the dust, but it could also
        be gas opacity for the hot regions. Or you could decide to specify a simple opacity
        law independent of the dust species in the disk. 

        The method compute_mean_opacity() creates and fills two arrays:

           self.mean_opacity_planck[0:nz]
           self.mean_opacity_rosseland[0:nz]

        which are the Planck-mean and Rosseland-mean opacities respectively. They are 
        normalized to the *gas* density, i.e. the Rosseland extinction coefficient would be:

           extinction_coefficient[0:nz] = self.rhogas[0:nz] * self.mean_opacity_rosseland[0:nz]

        and the total vertical Rosseland optical depth would then be 

           tau_rosseland_total = 2 * ( extinction_coefficient * self.dz ).sum()

        where the factor of 2 is simply because we only model the upper half of the disk.

        The normalization to the gas density (instead of the dust density) is simply 
        because "the" gas of the disk is just a single entity, whereas DISKLAB allows
        multiple dust species. The mean opacity is thus "cross section per gram of gas",
        but it will (or may) include any opacity bearing material suspended in the gas.
        So for a typical dust opacity we get that the mean opacity is the dust-to-gas
        ratio times the dust opacity. 

        Note that if the temperature of the disk changes, you will have to call this
        method compute_mean_opacity() again to recompute the opacity arrays. This will
        typically happen when doing a vertical structure iteration, where the temperature
        changes with iteration step. 

        Note also that if the opacities depend on a z-dependent distribution of disk
        components (e.g. on dust settling or on a z-dependent disk chemical composition),
        then one also has to re-call this method every time this vertical distribution
        changes. 

        Calling compute_mean_opacity() will automatically delete the previously installed
        mean opacities, so you can call compute_mean_opacity() as often as you like,
        without worrying about cluttering memory.

        Tip: Better call the method compute_mean_opacity() too often than too few times,
             because if you forget to call compute_mean_opacity() after a change in the
             disk structure, you may get wrong results because the mean opacities will
             be wrongly distributed vertically. 
        
        The method compute_mean_opacity() is a very general method: it will allow 
        different kinds of opacity models to be installed. 

        ARGUMENTS:

          meanopacitymodel  A list. First element is a string containing the name of the
                            opacity model. The further elements contain information used
                            by that opacity model, and these elements can be different
                            for different opacity models. They are described below.

                            ---> If meanopacitymodel is None, then this method will use
                            self.meanopacitymodel

        OPACITY MODELS AVAILABLE:

          'supersimple'     The simplest opacity model available: you simply specify
                            a value to be used. The second element of the meanopacitymodel
                            list is a dictionary with information about this opacity.
                            The simplest way is:

                             meanopacitymodel = ['supersimple',{'kappagas':1e0}]

                            You can also specify a hypothetical dust opacity, and a dust-to-gas
                            ratio:

                             meanopacitymodel = ['supersimple',{'dusttogas':0.01,'kappadust':1e2}]

                            (note that both examples give the same result). 

                            You can also use this model to specify a z-dependent opacity,
                            simply by giving an array instead of a value:

                             kappaarray       = np.ones_like(self.rhogas)
                             meanopacitymodel = ['supersimple',{'kappagas':kappaarray}]

                            where of course you set kappaarray to some more useful 
                            array than just np.ones_like(self.rhogas), as long as it
                            has the same number of elements as self.rhogas.

          'dustcomponents'  This will construct the mean opacity arrays from the available
                            dust components in the disk (or from the dust components you
                            explicitly give as arguments to this method). The second 
                            element of the list is a dictionary with further settings.
                            The most important dictionary element is 'method'. It can
                            have the following values:

                            method = 'fullcalculation':
                                      Compute the mean opacities from the full 
                                      frequency-dependent opacities of the dust components. 
                                      This model is very time-consuming, because it will
                                      recalculate the integrals over the full frequency grids. 
                                      For fast calculations of disk models, this is not ideal.
                                      But there can be circumstances by which this is the 
                                      better method: if different dust species mix/drift 
                                      in different ways, so that the composition of the
                                      dust mixture is different at different times. 

                            method = 'simplemixing':
                                      Use mean opacities from each of the dust species
                                      individually, and average them weighted by abundance.
                                      For a single dust species this is of course exact.
                                      For multiple dust species this is not quite correct,
                                      but it is fast. The reason why it is not quite
                                      correct is that the Rosseland mean of the mixed 
                                      frequency dependent opacity is not equal to the 
                                      average of the Rosseland mean of the individual 
                                      dust opacities. It is only correct if the frequency-
                                      dependent opacities are 'correlated'. In atmospheric
                                      radiative transfer physics they call this the 
                                      'correlated k assumption'. It is the method of
                                      choice if one wants to allow time- and space-
                                      varying dust abundances, while avoiding the time-
                                      consuming 'fullcalculation' method. 

                            So if you choose 'simplemixing' then this if what the meanopacitymodel
                            should look like:

                             meanopacitymodel = ['dustcomponents',{'method':'simplemixing'}]

          'tabulated'       This method will look up the opacity from a table that you 
                            provide, and it will interpolate in that table. The meanopacitymodel
                            has to contain this table:

                             meanopacitymodel = ['tabulated',{'rhogrid':rhogas,'tempgrid':temp, \
                                                              'kappa_planck':kappa_planck,      \
                                                              'kappa_rosseland':kappa_rosseland,\
                                                              'method':'linear'}]

                            where rhogas[0:nrho] and temp[0:ntemp] are two 1-D arrays giving the
                            coordinates of the table, and kappa_planck[0:nrho,0:ntemp] and
                            kappa_rosseland[0:nrho,0:ntemp] are the 2-D tables of opacity in
                            units of cm^2/gram-of-gas. 

                            Note that since these opacities can be extremely steep functions of 
                            density and temperature, it is often better to do the tabulation in
                            logarithmic form. You can do this, by specifying in the meanopacitymodel
                            instead of 'kappa_planck' and 'kappa_rosseland' the arrays
                            'ln_kappa_planck' and 'ln_kappa_rosseland', which then should be the
                            natural logarithms of kappa_planck and kappa_rosseland, respectively:

                             ln_kappa_planck    = np.log(kappa_planck)
                             ln_kappa_rosseland = np.log(kappa_rosseland)
                             meanopacitymodel = ['tabulated',{'rhogrid':rhogas,'tempgrid':temp,       \
                                                              'ln_kappa_planck':ln_kappa_planck,      \
                                                              'ln_kappa_rosseland':ln_kappa_rosseland,\
                                                              'method':'linear'}]

                            The resulting interpolated values will then automatically be 
                            np.exp(...) again, so that the result is again the actual opacity instead
                            of the np.log(...) of the opacity.

          'belllin'         This is the well-known Bell & Lin opacity table.
                            Set meanopacitymodel to:

                             meanopacitymodel = ['belllin']

        """
        #
        # Make sure that the mean opacity arrays exist
        #
        if not hasattr(self,'mean_opacity_planck'): self.mean_opacity_planck = np.zeros_like(self.rhogas)
        if not hasattr(self,'mean_opacity_rosseland'): self.mean_opacity_rosseland = np.zeros_like(self.rhogas)
        #
        # Get meanopacitymodel
        #
        if meanopacitymodel is None:
            assert hasattr(self,'meanopacitymodel'), 'To install the mean opacities you must given an opacity model.'
            meanopacitymodel = self.meanopacitymodel
        #
        # Check if meanopacitymodel is a scalar
        #
        if np.isscalar(meanopacitymodel):
            meanopacitymodel = [meanopacitymodel]
        self.meanopacitymodel = meanopacitymodel
        #
        # If we have dust components, then extract information from them
        #
        rhodust = None
        grain   = None
        if hasattr(self,'dust'):
            rhodust = []
            grain   = []
            if type(self.dust)==list:
                for d in self.dust:
                    if hasattr(d,'rho'):
                        rhodust.append(d.rho)
                    else:
                        rhodust.append(None)
                    if hasattr(d,'grain'):
                        grain.append(d.grain)
                    else:
                        grain.append(None)
        #
        # Check if we have the midplane gas density and temperature available
        #
        if hasattr(self,'rhogas'):
            rhogas = self.rhogas
        else:
            rhogas = None
        if hasattr(self,'temp'):
            tgas = self.temp
        else:
            tgas = None
        #
        # Now handle the different meanopacitymodels:
        #
        meanopac = evaluate_meanopacity(meanopacitymodel,rhogas,tgas,rhodust=rhodust,grain=grain)
        self.mean_opacity_planck[:]    = meanopac['planck']
        self.mean_opacity_rosseland[:] = meanopac['rosseland']
        
    def irradiate_with_flaring_index(self):
        """
        Compute the absorbed stellar radiation in the surface layer. The albedo is assumed to be zero, so
        that all the stellar radiation is absorbed. The irradiation is done in a flaring-index kind of
        way: irradiation from the top with an irradiation angle.
        """
        z            = self.z
        nz           = len(z)
        if not hasattr(self,'irrad_src'):     self.irrad_src     = np.zeros(nz)
        if not hasattr(self,'irrad_jmean'):   self.irrad_jmean   = np.zeros(nz)
        if not hasattr(self,'irrad_taugraz'): self.irrad_taugraz = np.zeros(nz+1)
        if not hasattr(self,'irrad_tauvert'): self.irrad_tauvert = np.zeros(nz+1)
        if not hasattr(self,'irrad_flux'):    self.irrad_flux    = np.zeros(nz+1)
        if not hasattr(self,'irrad_flang'):   self.irrad_flang   = np.zeros(nz)
        r            = self.r
        dz           = self.dz
        rhokap       = self.rhogas * self.mean_opacity_planck
        flux         = self.lstar / ( 4*nc.pi * r**2 )
        src          = self.irrad_src
        jmean        = self.irrad_jmean
        self.irrad_flux[nz] = flux
        for iz in range(nz-1,-1,-1):
            if hasattr(self,'flidx'):
                flang    = self.flidx * z[iz] / r
            else:
                flang    = self.flang
            dtau         = rhokap[iz] * dz[iz] / ( flang + 1e-10 )
            fluxprev     = flux
            flux        *= np.exp(-dtau)
            src[iz]      = ( fluxprev - flux ) * flang / dz[iz]
            jmean[iz]    = 0.5 * ( fluxprev + flux ) / ( 4*nc.pi )
            self.irrad_flux[iz]    = flux
            self.irrad_taugraz[iz] = self.irrad_taugraz[iz+1] + dtau
            self.irrad_tauvert[iz] = self.irrad_tauvert[iz+1] + dtau * ( flang + 1e-10 )
            self.irrad_flang[iz]   = flang

    def compute_local_shear_viscosity(self):
        """
        Given the Shakura-Sunyaev alpha parameter self.alphavisc, compute and store
        the viscosity self.nuvisc = alpha*cs^2/omk
        """
        z                = self.z
        nz               = len(z)
        assert hasattr(self,'alphavisc'), "Error: Cannot compute viscosity if alphavisc is not set."
        if not hasattr(self,'nuvisc'): self.nuvisc = np.zeros(nz)
        alpha            = self.alphavisc
        temp             = self.tgas
        cs2              = nc.kk*temp/(self.mugas*nc.mp)
        omk              = self.omk
        self.nuvisc[:]   = alpha*cs2/omk

    def compute_viscous_heating(self):
        """
        Compute the viscous heating source term. This is implemented here is a
        simple way: q = (9/4)*rhogas*nu*omk^2 with nu=nuvisc computed by
        the compute_local_shear_viscosity() routine.
        """
        z                = self.z
        nz               = len(z)
        if not hasattr(self,'visc_src'): self.visc_src = np.zeros(nz)
        self.compute_local_shear_viscosity()
        omk              = self.omk
        rho              = self.rhogas
        nu               = self.nuvisc
        self.visc_src[:] = (9./4.)*rho*nu*omk**2

    def solve_vert_rad_diffusion(self):
        """
        Given a possible irrad_src and a possible visc_src, integrate the diffusion equation to
        get the diffuse radiation field. This is the stationary state case. For a time-dependent
        time step, use timestep_vert_rad_diffusion()
        """
        if not hasattr(self,'diff_jmean'):  self.diff_jmean  = np.zeros_like(self.z)
        jmean        = self.diff_jmean
        z            = self.z
        nz           = len(z)
        #
        # The opacity at the interfaces (note: nz-1 elements)
        #
        rhokappa     = self.rhogas * self.mean_opacity_rosseland
        meanalphai   = 0.5 * ( rhokappa[1:] + rhokappa[:-1] )
        #
        # Compute or get the source
        #
        src          = np.zeros_like(self.z)
        if hasattr(self,'irrad_src'):
            src += self.irrad_src
        if hasattr(self,'visc_src'):
            src += self.visc_src
        #
        # Integrate the flux at the interfaces (note: here nz+1 elements)
        #
        if not hasattr(self,'diff_hflux'):    self.diff_hflux    = np.zeros(nz+1)
        hflux = self.diff_hflux
        dz    = self.dz
        hflux[0] = 0.0
        for iz in range(1,nz+1):
            hflux[iz] = hflux[iz-1] + dz[iz-1] * src[iz-1] / ( 4 * nc.pi )
        #
        # Now integrate back down
        #
        jmean[nz-1] = hflux[nz] * np.sqrt(3.0)
        for iz in range(nz-2,-1,-1):
            jmean[iz] = jmean[iz+1] + 3 * hflux[iz+1] * meanalphai[iz] * ( z[iz+1] - z[iz] )
        #
        # Compute the temperature throughout the vertical structure
        #
        self.compute_temperature_from_radiation()
            
    def timestep_vert_rad_diffusion(self,dt):
        """
        For time-dependent radiative diffusion, use this subroutine. For the stationary
        case, use solve_vert_rad_diffusion().
        """
        assert hasattr(self,'gamma'), "Error: The gamma (ratio of specific heats) must be specified."
        assert hasattr(self,'mugas'), "Error: The mugas must be specified."
        if not hasattr(self,'diff_jmean'):  self.diff_jmean  = np.zeros_like(self.z)
        #
        # Get or compute variables
        #
        self.cv = nc.kk / ( (self.gamma-1.0) * self.mugas * nc.mp )
        jmean   = self.diff_jmean
        z       = self.z
        #
        # Compute the f_c factor of Kuiper, Klahr, Dullemond, Kley & Henning (2010)
        #
        fc    = 1.0 / ( 1.0 + self.cv*self.rhogas/(4*nc.aa*self.tgas**3) )
        #
        # Since the 1-D diffusion solver does not have a prefactor before the
        # time derivative, we simply modify the time step
        #
        cfcdt = nc.cc * fc[1:-1] * dt
        #
        # Compute the mean intensity from the local temperature
        #
        jmean[:] = ( nc.ss / nc.pi ) * self.tgas**4
        #
        # Set the diffusion coefficient at cell interfaces
        #
        rhkap = self.rhogas * self.mean_opacity_rosseland
        d     = 1.0 / ( 3.0 * 0.5 * ( rhkap[1:] + rhkap[:-1] ))
        #
        # Set the source term
        #
        s     = self.irrad_src / ( 4*nc.pi )
        #
        # Boundary conditions
        #
        bcl   = (1.0,0.0,0.0,0)
        bcr   = (d[-1],1./np.sqrt(3.0),0.0,0)
        #
        # Solve for one time step
        #
        v     = np.zeros_like(d)
        g     = np.ones_like(jmean)
        jmean[:] = solvediffonedee(z,jmean,v,d,g,s,bcl,bcr,dt=cfcdt,int=True)
        #
        # Recompute the temperature
        #
        self.compute_temperature_from_radiation()

    def compute_temperature_from_radiation(self):
        """
        Compute the gas/dust temperature from the direct and diffuse radiation field.
        """
        self.tgas = ( ( self.irrad_jmean + self.diff_jmean ) * nc.pi / nc.ss )**0.25

    def compute_hflux_from_jmean(self):
        """
        For debugging purposes: re-compute H from J.
        """
        z     = self.z
        nz    = len(z)
        if not hasattr(self,'diff_hflux'):    self.diff_hflux    = np.zeros(nz+1)
        hflux = self.diff_hflux
        jmean = self.diff_jmean
        rhok  = self.rhogas * self.mean_opacity_rosseland
        rhoki = 0.5*(rhok[1:]+rhok[:-1])
        hflux[1:-1] = -(jmean[1:]-jmean[:-1])/(z[1:]-z[:-1])/(3*rhoki)
        hflux[0]  = 0.0
        hflux[-1] = hflux[-2]

    def iterate_vertical_structure(self,tol=1e-10,maxiter=100,meanopacitymodel=None):
        """
        Wrapper function that iterates the vertical structure hydrostatically and
        radiative transferly. The tolerance is given by tol. The maximum nr of
        iterations is given by maxiter.
        """
        if meanopacitymodel is None:
            assert hasattr(self,'meanopacitymodel'), "Error: Must specify self.meanopacitymodel."
        else:
            self.meanopacitymodel = meanopacitymodel
        tprev = self.tgas.copy()
        for iter in range(maxiter):
            self.compute_mean_opacity()
            self.irradiate_with_flaring_index()
            if hasattr(self,'alphavisc'): self.compute_viscous_heating()
            self.solve_vert_rad_diffusion()
            self.compute_temperature_from_radiation()
            self.compute_rhogas_hydrostatic()
            error = np.abs((self.tgas-tprev)/(self.tgas+tprev)).max()
            if error<tol: break
            tprev = self.tgas.copy()
        self.iter=iter


class diskvertcomponent(object):
    """
    To allow the disk to contain one or more dust or chemical components, this class contains
    all the methods needed for moving such a component vertically (e.g. dust drift, mixing etc).
    """
    def __init__(self,diskvertstruct,massfraction,agrain=None,xigrain=None):
        self.diskvertstruct = diskvertstruct    # Link to the parent disk vertical structure model
        self.z              = diskvertstruct.z  # Link vertical grid to disk model for convenience
        self.dz             = diskvertstruct.dz # Link vertical grid to disk model for convenience
        nz = len(self.z)
        self.rho            = diskvertstruct.rhogas * massfraction
        if xigrain is not None:
            assert np.isscalar(agrain), "xigrain must be a scalar"
            self.xigrain = xigrain
        else:
            self.xigrain = 3.0         # Default dust material density
        if agrain is not None:
            assert np.isscalar(agrain), "agrain must be a scalar"
            self.agrain  = agrain
            self.compute_tstop_from_agrain()

    def compute_mgrain_from_agrain(self):
        """
        Compute the grain mass everywhere.
        """
        assert hasattr(self,'agrain'),  "Error: no agrain present; cannot compute grain mass"
        assert hasattr(self,'xigrain'), "Error: no xigrain present; cannot compute grain mass"
        nz = len(self.z)
        if not hasattr(self,'mgrain'):  self.mgrain  = np.zeros(nz)
        agrain  = np.zeros(nz) + self.agrain
        xigrain = np.zeros(nz) + self.xigrain
        self.mgrain[:] = (4*nc.pi/3.)*xigrain*agrain**3

    def compute_tstop_from_agrain(self,dv=1e3):
        """
        Compute the stopping time of the grain at each position.
        """
        nz    = len(self.z)
        if not hasattr(self,'tstop'):  self.tstop  = np.zeros(nz)
        self.compute_mgrain_from_agrain()
        nz          = len(self.z)
        mgrain      = self.mgrain
        agrain      = self.agrain
        xigrain     = self.xigrain
        for iz in range(nz):
            d       = grainmodel(agrain=agrain,xigrain=xigrain)
            d.mgrain= mgrain
            rhogas  = self.diskvertstruct.rhogas[iz]
            tgas    = self.diskvertstruct.tgas[iz]
            d.compute_tstop(rhogas,tgas,dv)
            self.tstop[iz] = d.tstop

    def compute_vsett_and_dmix(self):
        """
        Compute the settling velocity and the turbulent diffusion coefficient
        for this species.
        """
        z       = self.z
        nz      = len(z)
        omk     = self.diskvertstruct.omk
        tgas    = self.diskvertstruct.tgas
        mugas   = self.diskvertstruct.mugas
        cs2     = nc.kk*tgas/(mugas*nc.mp)
        tstop   = self.tstop
        St      = omk*tstop
        self.vsett = np.maximum(-z*omk**2*tstop,-omk*z)
        if hasattr(self.diskvertstruct,'alphamix'):
            dmix = self.diskvertstruct.alphamix*cs2/self.omk / self.diskvertstructl.Sc
        else:
            self.diskvertstruct.compute_local_shear_viscosity()
            dmix = self.diskvertstruct.nuvisc / self.diskvertstruct.Sc
        self.dmix = dmix + np.zeros(nz)
        self.dmix[:] *= 1.0 / ( 1.0 + St**2 )

    def timestep_settling_mixing(self,dt):
        """
        Do a time step of the settling mixing equation.
        """
        self.compute_tstop_from_agrain()
        self.compute_vsett_and_dmix()
        z       = self.z
        nz      = len(z)
        rhogas  = self.diskvertstruct.rhogas
        s       = np.zeros(nz)
        vdusti  = 0.5 * ( self.vsett[1:] + self.vsett[:-1] )
        diffi   = 0.5 * ( self.dmix[1:]  + self.dmix[:-1]  )
        vdusti[-1] = 0.
        vdusti[0]  = 0.
        bcl     = (1.,0.,0.,1)
        bcr     = (1.,0.,0.,0)
        self.rho[:] = solvediffonedee(z,self.rho,vdusti,diffi,rhogas,s,bcl,bcr,dt=dt,int=True,upwind=True)


class diskvert2d(object):
    """
    This object links a series of 1-D vertical disk structure models
    together into a 1+1-D model. It also provides some true 2-D features.

    ARGUMENTS:
      disk       A 1-D diskmodel object (see diskmodel.py)
      zrmax      The upper z of the vertical grid in units of r.
                 This can be an array (a different zrmax for each r)
                 or a scalar (the same zrmax for all r). The latter is
                 required if you want to use the 2-D radiative diffusion
                 model and/or the radial ray-trace model for irradiation.
    """
    def __init__(self,disk,zrmax=None,nz=100,meanopacitymodel=None,   \
                 irradmode='flaring angle',mugas=2.3):
        self.disk = disk
        if zrmax is None:
            self.zrmax = 6*(disk.hp/disk.r).max()
        else:
            self.zrmax = zrmax
        nr    = len(disk.r)
        self.nz = nz
        self.r = disk.r
        mstar = disk.mstar
        lstar = disk.lstar
        alpha = disk.alpha
        Sc    = disk.Sc
        self.mugas = mugas
        self.gamma = 7./5.   # NOTE: For cold outer parts this should be 5./3.
        if irradmode=='flaring angle':
            assert hasattr(disk,'flang'), "Disk radial model object does not contain flaring angle"
            flidx = None
            flang = disk.flang
        elif irradmode=='flaring index':
            assert hasattr(disk,'flidx'), "Disk radial model object does not contain flaring index"
            flidx = disk.flidx
            flang = None
        elif irradmode=='radial raytrace':
            flidx = None
            flang = None
        else:
            raise ValueError('Do not know irradmode')
        self.verts = []
        for ir in range(nr):
            if np.isscalar(self.zrmax):
                zrm = self.zrmax
            else:
                zrm = self.zrmax[ir]
            vert = diskvertmodel(mstar,disk.r[ir],disk.sigma[ir],nz=nz,   \
                                 zrmax=zrm,lstar=lstar,flidx=flidx,       \
                                 flang=flang,meanopacitymodel=meanopacitymodel, \
                                 mugas=mugas,gamma=self.gamma,alphavisc=alpha,  \
                                 Sc=Sc)
            self.verts.append(vert)
        if np.isscalar(self.zrmax):
            # If zrmax is a scalar, then the z-grid is self-similar, i.e. z/r = constant
            # along each z gridpoint. This is necessary for 2-D radiative transfer.
            self.zdivr = self.verts[-1].z/disk.r[-1]
            self.theta = nc.pi/2 - self.zdivr
            self.rr,self.tt = np.meshgrid(self.r,self.theta)


    def radial_raytrace(self):
        """
        Compute the irradiation of the disk by radial ray-tracing.
        This works only when all the vertical structure models have
        the same z/r grid, i.e. when their z-grids are the same apart
        from the scaling with r.

        Note: For simplicity we do not account for the geometric
              effects of order (z/r)^2, i.e. we do not distinguish
              between a cylindrical coordinate treatment or a
              spherical coordinate treatment.
        Note: Here the source term due to the irradiation is not,
              as in the 1D vertical model, computed as a flux
              difference, but simply as flux times opacity.
        """
        assert np.isscalar(self.zrmax), "Radial raytracing only works if the z-grids line up, i.e. all have the same z/r"
        assert len(self.verts)==len(self.disk.r), "Radial raytrace only works if you have exactly the same nr of vertical models as radial grid points."
        nr         = len(self.disk.r)
        nz         = self.nz
        r          = self.disk.r[0]
        irrad_lum  = np.zeros(nz) + self.disk.lstar
        self.verts[0].irrad_flux[:-1] = irrad_lum.copy() / ( 4*nc.pi * r**2 )
        for ir in range(1,nr):
            r       = self.disk.r[ir]
            dr      = self.disk.r[ir] - self.disk.r[ir-1]
            rhokap0 = self.verts[ir-1].rhogas * self.verts[ir-1].mean_opacity_planck
            rhokap1 = self.verts[ir].rhogas * self.verts[ir].mean_opacity_planck
            rhokap  = 0.5*(rhokap0+rhokap1)
            dtau    = rhokap*dr
            irrad_lum[:] *= np.exp(-dtau)
            self.verts[ir].irrad_flux[:-1]  = irrad_lum.copy() / ( 4*nc.pi * r**2 )
            self.verts[ir].irrad_jmean[:] = self.verts[ir].irrad_flux[:-1] / ( 4 * nc.pi )
            self.verts[ir].irrad_src[:]   = self.verts[ir].irrad_flux[:-1] * rhokap1

    def solve_2d_rad_diffusion(self,floorparam=1e-6,thist=False,limiter=None, \
                               linsol_convcrit=1e-10,linsol_itermax=10000,    \
                               nonlin_convcrit=1e-3,nonlin_itermax=20):
        """
        Solve the 2-D r-z (or more accurately: r-theta) radiative diffusion problem.

        Note: This method requires the solvediff3d.py library.
        Note: Often the rho*kappa drops so deeply that the diffusion approximation breaks
              down. We must put a lower floor. Given that the dimension of rho*kappa is
              1/cm, the lower limit also must have a dimension of 1/length. We use the
              radius r for that, and set this floor to floorparam/r.
        Note: When you wish to start with a reset flux limiter for the FLD, and you
              have called this method before, you may want to set self.fld_limiter=None,
              because by default the values of the limiter from the earlier call are
              used (for faster convergence).
        """
        #
        # If either "limiter" is set or is an attribute, then use this array
        # as the flux limiter. Otherwise set fluxlimiter to 1.0 as a start.
        #
        if limiter is None:
            if hasattr(self,'fld_limiter'):
                limiter = self.fld_limiter
        #
        # Convert from 1+1D to true 2D (r,theta) polar coordinate system.
        #
        r    = self.disk.r
        th   = np.pi/2. - self.verts[0].z/self.verts[0].r
        th   = th[::-1]
        ph   = np.array([0.0])
        nr   = len(r)
        nth  = len(th)
        nph  = 1
        a    = np.zeros((nr,nth,nph))
        s    = np.zeros((nr,nth,nph))
        jirr = np.zeros((nr,nth,nph))
        t    = np.zeros((nr,nth,nph))
        cvrho= np.zeros((nr,nth,nph))
        aflr = np.zeros((nr,nth,nph))
        for ir in range(nr):
            aflr[ir,:,0] = floorparam/r[ir]
            a[ir,:,0] = (self.verts[ir].rhogas * self.verts[ir].mean_opacity_rosseland)[::-1]
            if hasattr(self.verts[ir],'irrad_src'):
                s[ir,:,0] += self.verts[ir].irrad_src[::-1] / (4*nc.pi)
            if hasattr(self.verts[ir],'visc_src'):
                s[ir,:,0] += self.verts[ir].visc_src[::-1] / (4*nc.pi)
            t[ir,:,0] = self.verts[ir].tgas[::-1]
            jirr[ir,:,0] = (self.verts[ir].irrad_flux[:-1])[::-1] / (4*nc.pi)
            cvrho[ir,:,0] = self.verts[ir].rhogas[::-1] * nc.kk / ( (self.gamma-1.0) * self.mugas * nc.mp )
        #
        # To avoid crashing the diffusion algorithm on too low optical depths,
        # add a floor value to the extinction coefficient.
        #
        ii      = np.where(a<aflr)
        a[ii]   = aflr[ii]
        #
        # Specify the boundary condition for the Flux-limited diffusion
        #
        bc      = [[['flux',1.,-1.,0.],['dirichlet',1e-3,0.,0.]],  \
                   [['flux',1.,-1.,0.],['flux',1.,0.,0.]],   \
                   None]
        #
        # Now call the FLD solver for spherical coordinates, and with the irradiation
        # temperature as a source term.
        #
        geom    = 'spherical'
        tirr    = ( jirr * (nc.pi/nc.ss) )**0.25
        t,j,h,l,err = solvefld3d(geom,r,th,ph,a,s,bc,tinit=t,tirrad=tirr,cvrho=cvrho, \
                                 linsol_convcrit=linsol_convcrit,                     \
                                 linsol_itermax=linsol_itermax,dt=0,retrad=True,      \
                                 nonlin_convcrit=nonlin_convcrit,                     \
                                 nonlin_itermax=nonlin_itermax,                       \
                                 limiter=limiter,thist=thist)
        #
        # Re-insert results into the 1+1D vertical structure models
        #
        for ir in range(nr):
            if thist:
                self.verts[ir].tgas[:] = t[-1][ir,::-1,0]
            else:
                self.verts[ir].tgas[:] = t[ir,::-1,0]
            if hasattr(self.verts[ir],'irrad_jmean'):
                self.verts[ir].irrad_jmean[:] = jirr[ir,::-1,0]
            if hasattr(self.verts[ir],'diff_jmean'):
                self.verts[ir].diff_jmean[:]  = j[ir,::-1,0]
            if hasattr(self.verts[ir],'diff_hflux'):
                self.verts[ir].diff_hflux[1:-1] = -(h[1][ir,:-1,0])[::-1]
                self.verts[ir].diff_hflux[0]    = 0.0
                self.verts[ir].diff_hflux[-1]   = self.verts[ir].diff_hflux[-2]
        #
        # Also insert the results into truly 2-D arrays in (r,theta) coordinates.
        #
        # NOTE: Theta points south, i.e. theta=0 is the north polar axis, theta=pi/2 is
        #       the midplane, i.e. the standard definition of spherical (polar)
        #       coordinates. So beware that theta points in opposite direction as z/r.
        #
        if thist:
            self.temp = t[-1][:,:,:]
            self.fld_thistory = t
        else:
            self.temp    = t
        self.rhokappa    = a
        self.src         = s
        self.jirr        = jirr
        self.cvrho       = cvrho
        self.fld_jmean   = j
        self.fld_hflux   = h
        self.fld_limiter = l
        self.fld_err     = err
