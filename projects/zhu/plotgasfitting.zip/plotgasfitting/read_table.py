import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def mapping_func(x, left, right):
    """
    This is a function that stretch and squeeze y = x, 0 <= x <=1,
    using hyperbolic tangent function tanh(x).
    
    ARGUMENT:
    x: a point between left and right
    left: the left point on tanh(x), constrained to x < 0
    right: the right point on tanh(x), constrained to x > 0
    
    RETURN:
    The new y, range from 0 to 1.
    """
    if (left >= right):
        raise ValueError("the right end should be larger than left end!")
    x = x * (right-left) + left
    y_left = np.tanh(left)
    y_right= np.tanh(right)
    return (np.tanh(x) - y_left)  / (y_right - y_left)

def like_heaviside(x):
    """
    same as np.heaviside(x, 0.5), but since heaviside only available
    starting from numpy 1.13.1, we use np.sign instead
    """
    return 0.5 * (np.sign(x) + 1.)

def piecewise_gap_half_cosine_tanh(x, rij, fij, xij):
    """
    The modified half period of cosine function,
    using hyperbolic tangent function tanh(x).
    
    ARGUMENT:
    x:   a point between ri and rj
    rij: a tuple that contains left end (ri) and right end (rj) of half cosine.
    fij: a tuple that contains the values (f(ri), f(rj)) of left end and right end of half cosine.
    xij: a tuple that contains left and right points on tanh(x)
    
    RETURN:
    The value at x, if x < ri or x > rj, then return 0
    if x == ri or x == rj, return 0.5 * fi or 0.5 * fj
    """
    
    k = like_heaviside(x-rij[0]) * like_heaviside(rij[1]-x)
    x = (x-rij[0]) / (rij[-1]-rij[0])
    mu = mapping_func(x, xij[0], xij[1])
    f = fij[0] + (fij[0]- fij[-1]) * (np.cos(np.pi* mu) - 1.) * 0.5
    return f * k 

def bestfit_func(x, params):
    """
    Return the log10(normalized density profile):
    normalized density profile = Sigma(r) / (A*r**p)
    
    ARGUMENT:
    x:   a point between ri and rj
    
    params: an 1d array that contains parameters in order:
            A, p, ri1 ,rj1, ..., rin, rjn,
                  fi1, fj1, ..., fin, fjn,
                  xi1, xj1, ..., xin, xjn.
            where A and p, are the parameter for the background fitting:
                        Simga(r) = A*r**p, p is close to -1.
            rik, rjk are the left and right points of each piecewise half cosine.
            fik, fjk are f(rik), f(rjk)
        and xik, xjk are the left and right points on tanh(x) functions. These 2n
        parameters were fitted and determine the slope of half cosine function.
        
    RETURN:
    The value at x, if x < ri1 or x > rjn, return 0
    """    
    normed_params = params[2:]
    r,sigma, rfit = normed_params[:int(len(normed_params)/3)],\
    normed_params[int(len(normed_params)/3):int(len(normed_params)*2/3)],\
    normed_params[int(len(normed_params)*2/3):]
    
    f = 0
    for i in range(int(len(r)/2)):
        f = f + piecewise_gap_half_cosine_tanh(x, r[2*i:2*i+2], sigma[2*i:2*i+2], rfit[2*i:2*i+2])
    
    f = f + sigma[-1] * like_heaviside(x - r[-1]) + sigma[0] * like_heaviside(r[0] - x)
    
    return f

def normed_sigma(x, params):
    """
    Return the Normalized Density Profile:
        normalized density profile = Sigma(r) / (A*r**p)
    
    ARGUMENT:
    x:   a point between ri and rj
    
    params: an 1d array that contains parameters in order:
            A, p, ri1 ,rj1, ..., rin, rjn,
                  fi1, fj1, ..., fin, fjn,
                  xi1, xj1, ..., xin, xjn.
            where A and p, are the parameter for the background fitting:
                        Simga(r) = A*r**p, p is close to -1.
            rik, rjk are the left and right points of each piecewise half cosine.
            fik, fjk are f(rik), f(rjk)
        and xik, xjk are the left and right points on tanh(x) functions. These 2n
        parameters were fitted and determine the slope of half cosine function.
        
    RETURN:
    The value at x, if x < ri1 or x >= rjn, then return 0
    """
    
    return np.power(10, bestfit_func(x, params))

def original_profile(x, params):
    """
    Return the Original Density Profile:
        Sigma(r) = normalized density profile * (A*r**p)
    
    ARGUMENT:
    x:   a point between ri and rj
    
    params: an 1d array that contains parameters in order:
            A, p, ri1 ,rj1, ..., rin, rjn,
                  fi1, fj1, ..., fin, fjn,
                  xi1, xj1, ..., xin, xjn.
            where A and p, are the parameter for the background fitting:
                        Simga(r) = A*r**p, p is close to -1.
            rik, rjk are the left and right points of each piecewise half cosine.
            fik, fjk are f(rik), f(rjk)
        and xik, xjk are the left and right points on tanh(x) functions. These 2n
        parameters were fitted and determine the slope of half cosine function.
        
    RETURN:
    The value at x, if x < ri1 or x >= rjn, then return 0
    """
    return normed_sigma(x, params) * (params[0] * np.power(x, params[1]))

def read_table(filebase="./", filename="fitting_params.csv"):
    """
    ARGUMENT:
    filebase: the directory base of this table
            default is the current directory
    filename: the filename of the table
            default is named "fitting_params.csv"
    
    RETURN:
    table in pandas DataFrame format
    you can directly print the table using print
    for more please see:
    https://pandas.pydata.org/pandas-docs/stable/cookbook.html
    """
    table = pd.read_csv(filebase+filename, index_col=0)
    return table

def get_params(runName, filebase="./", filename="fitting_params.csv"):
    """
    Return the fitting parameters for a specific run.
    
    ARGUMENT:
    runName: "outh{}p{}a{}em{}p{}_{}
        the first two brackets stands for h/r, reading like {} point {},
        the third and fourth brackets stands for alpha, reading like {} times 10 to minus {},
        the 5th bracket stands for the planet mass type
        the 6th bracket stands for the number of orbits at r=1
            
        runs on offer:
        aspect ratio h/r (h): 0.05 (0p05) and 0.1 (0p1)
        viscosity alpha(a)  : 1e-4 (1em4), 1e-3 (1em3) and 1e-2 (1em2)
        planet mass type (p): 3.3e-5 (0), 1e-4 (1), 3.3e-4 (2), 1e-3 (3), 3.3e-3 (4)
                            in code unit (Msun)
        orbits (after '_')  : 1000 for all the runs.
    
    Optional:
    filebase: the directory base of this table
            default is the current directory
    filename: the filename of the table
            default is named "fitting_params.csv"
    
    RETURN: 
    params: an 1d array that contains parameters in the order:
            A, p, ri1 ,rj1, ..., rin, rjn,
                  fi1, fj1, ..., fin, fjn,
                  xi1, xj1, ..., xin, xjn.
            where A and p, are the parameter for the background fitting:
                        Simga(r) = A*r**p, p is close to -1.
            rik, rjk are the left and right points of each piecewise half cosine.
            fik, fjk are f(rik), f(rjk)
        and xik, xjk are the left and right points on tanh(x) functions. These 2n
        parameters were fitted and determine the slope of half cosine function.
      
    EXAMPLE:
    In: get_params("outh0p05a1em4p2_1000")
    Out: an array with fitting parameters for the run whose
                            h/r     = 0.05
                            alpha   = 1e-4
                            Mplanet = 3.3e-4
                            orbits  = 1000
    """
    table = read_table(filebase, filename)
    aProfileParams = table.T[runName][:-1][table.T[runName].notnull()]
    params_array = np.array(aProfileParams, dtype=np.float64)
    return params_array

def get_ends(params_array):
    """
    return the left and right ends of the fitting region
    
    ARGUMENT:
    params_array: parameters read from table using
            get_params(runName, filebase, filename);
    
    RETURN:
    left and right ends of the fitting region
    (ri1, rjn)
    """
    len_paramswoAp = len(params_array[2:])
    return params_array[2:][0], params_array[2:][int(len_paramswoAp/3) - 1]

def plot_fitting_region(runName, sigma_type = "log(normed)",numPoints=100,\
                        filebase="./", filename="fitting_params.csv",\
                        linestyle="-", color="b", linewidth=2, label=None):
    """
    plot the fitting region and,
    return the gird points x and their value y
    
    If you want to make more varsertile plots, you can read in the data by yourself
    using read_table() or/and get_params() and plot the function using bestfit_func(),
    normed_sigma() or original_profile().
    
    ARGUMENT:
    runName: "outh{}p{}a{}em{}p{}_{}
        the first two brackets stands for h/r, reading like {} point {},
        the third and fourth brackets stands for alpha, reading like {} times 10 to minus {},
        the 5th bracket stands for the planet mass type
        the 6th bracket stands for the number of orbits at r=1
            
        runs on offer:
        aspect ratio h/r (h): 0.05 (0p05) and 0.1 (0p1)
        viscosity alpha(a)  : 1e-4 (1em4), 1e-3 (1em3) and 1e-2 (1em2)
        planet mass type (p): 3.3e-5 (0), 1e-4 (1), 3.3e-4 (2), 1e-3 (3), 3.3e-3 (4)
                            in code unit (Msun)
        orbits (after '_')  : 1000 for all the runs.
        
    Optional:
    sigma_type: type of plot you want to make
            "log(normed)":
            "normed":
            "original":
    
    numPoints: the number of points on r, default is 100
            the sampling is in log scale
            
    filebase: the directory base of this table
            default is the current directory
            
    filename: the filename of the table
            default is named "fitting_params.csv"
    
    linestyle: default is solid line
    color    : default is blue
    linewidth: default is 2
    label    : default is None
    
    RETURN:
    x and y, two 1d array, the first contains positions
                       and the second contains values y(x).
    
    """ 
    params_array = get_params(runName, filebase, filename)
    left, right = get_ends(params_array)
    x = np.logspace(np.log10(left), np.log10(right), numPoints)
    
    if   sigma_type == "log(normed)":
        y = bestfit_func(x, params_array)
        plt.ylabel(r"$log_{10}$$\sigma$(r)")
    elif sigma_type == "normed":
        y = normed_sigma(x, params_array)
        plt.ylabel(r"$\sigma$(r)")
    elif sigma_type == "original":
        y = original_profile(x, params_array)
        plt.ylabel(r"$\Sigma$(r)")
    else:
        raise ValueError("we cannot offer you this...")
    plt.plot(x, y, linestyle=linestyle, color=color, linewidth=linewidth, label=label)
    plt.xlabel("r")
    return x, y

def get_runName(aspectRatio= 0.1, viscosity= 1e-4, planetMass= 3.3e-5, orbits=1000):
    """
    ARGUMENT:
    
    aspectRatio:   h/r   (0.05 and 0.1 on offer)
    
    viscosity:     alpha (1e-4, 1e-3, 1e-2 on offer)
    
    planetMass:    planet mass in code unit (Msun) (3.3e-5, 1e-4, 3.3e-4, 1e-3, 3.3e-3 on offer)
    
    orbits:        number of orbits at r=1 (1000 on offer, will update later)
    
    RETURN
    runName: "outh{}p{}a{}em{}p{}_{}
        the first two brackets stands for h/r, reading like {} point {},
        the third and fourth brackets stands for alpha, reading like {} times 10 to minus {},
        the 5th bracket stands for the planet mass type
        the 6th bracket stands for the number of orbits at r=1
            
        runs on offer:
        aspect ratio h/r (h): 0.05 (0p05) and 0.1 (0p1)
        viscosity alpha(a)  : 1e-4 (1em4), 1e-3 (1em3) and 1e-2 (1em2)
        planet mass type (p): 3.3e-5 (0), 1e-4 (1), 3.3e-4 (2), 1e-3 (3), 3.3e-3 (4)
                            in code unit (Msun)
        orbits (after '_')  : 1000 for all the runs.
    """
    accuracy = 1e-6
    
    if abs((aspectRatio - 0.1)/0.1) < accuracy:
        aspectRatio = "0p1"
    elif abs((aspectRatio - 0.05)/0.05) < accuracy:
        aspectRatio = "0p05"
    else:
        raise ValueError("Sorry, we don't have this run.")
    
    if abs((viscosity - 1e-4)/1e-4) < accuracy:
        viscosity = "1em4"
    elif abs((viscosity - 1e-3)/1e-3) < accuracy:
        viscosity = "1em3"
    elif abs((viscosity - 1e-2)/1e-2) < accuracy:
        viscosity = "1em2"
    else:
        raise ValueError("Sorry, we don't have this run.")
        
    if abs((planetMass - 3.3e-5)/3.3e-5) < accuracy:
        planetType = "0"
    elif abs((planetMass - 1e-4)/1e-4) < accuracy:
        planetType = "1"
    elif abs((planetMass - 3.3e-4)/3.3e-4) < accuracy:
        planetType = "2"
    elif abs((planetMass - 1e-3)/1e-3) < accuracy:
        planetType = "3"
    elif abs((planetMass - 3.3e-3)/3.3e-3) < accuracy:
        planetType = "4"
    else:
        raise ValueError("Sorry, we don't have this run.")
    
    if (orbits != 1000) & (orbits != 100):
        raise ValueError("Sorry, we don't have this run.")
    if orbits == 100:
        if (viscosity != "1em3") & (viscosity != "1em4"):
            raise ValueError("Sorry, for 100 orbits, we only fit alpha = 1e-4 and 1e-3.")
        
    return "outh" + aspectRatio + "a" + viscosity + "p" + planetType + "_" + str(orbits)
