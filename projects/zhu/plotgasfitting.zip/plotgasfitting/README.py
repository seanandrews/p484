All the functions from reading the table to plotting curves are in read_table.py
numpy, pandas and matplotlib are requried packages.
The Jupyter Notebook tableReadPlot.ipynb contains an example.
If you have any problem, please email shjzhang@umich.edu

Shangjia Z., June 3rd, 2018